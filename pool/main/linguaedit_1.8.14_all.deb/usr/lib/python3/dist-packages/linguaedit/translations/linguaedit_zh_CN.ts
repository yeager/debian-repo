<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="zh_CN">
    <context>
        <name>AIReviewDialog</name>
        <message>
            <source>AI Translation Review</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Analysis</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Analyzing translation...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Apply Suggestion</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Score:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Analysis error: </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Improvement suggestions:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Explanation:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No specific suggestions.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Could not analyze translation: </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source text:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Text to Review</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation:</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>AchievementManager</name>
        <message>
            <source>Complete 10 translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Complete 100 translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Complete 1000 translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Complete 50 translations without using auto-translate</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Complete your first translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Completionist</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Dedicated Translator</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Early Bird</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>First Steps</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Format Explorer</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fully translate a file (100% complete)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Getting Into Rhythm</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Getting Started</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Linguistic Expert</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Night Owl</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Perfectionist</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Polyglot</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Speed Demon</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translate 50 strings in one hour</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translate after 10 PM</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translate before 8 AM</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translate for 3 days in a row</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translate for 30 days in a row</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translate for 7 days in a row</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Master</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unstoppable</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Week Warrior</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Work with 3 different languages</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Work with 5 different file formats</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Work with 5 different languages</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>AchievementWidget</name>
        <message>
            <source>Unlocked: {}</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>AchievementsDialog</name>
        <message>
            <source>Achievement Progress</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Achievements</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>All</source>
            <translation>全部</translation>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Locked</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Overall Progress:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Statistics</source>
            <translation>统计</translation>
        </message>
        <message>
            <source>Translations: {0} | Streak: {1} days | Languages: {2}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unlocked</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>BatchEditDialog</name>
        <message>
            <source>Accept all fuzzy translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>After</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Apply Changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Apply changes to %d entries?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Batch Edit</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Before</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Case sensitive</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Clear fuzzy flag from all translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Completed successfully. %d entries modified.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Completed with %d errors. %d entries modified.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Confirm Changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copy Source</source>
            <translation>复制源文本</translation>
        </message>
        <message>
            <source>Copy source text to empty translation fields.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copy source to empty translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Entry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fuzzy Operations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fuzzy: </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Mark all translations as fuzzy</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Operation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Options</source>
            <translation>选项</translation>
        </message>
        <message>
            <source>Please enter text to find.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Preview</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Processing...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Regular expression</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Replace:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search &amp; Replace</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source Copy</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Text change</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Warning</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Yes</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>BatchTranslateDialog</name>
        <message>
            <source> (API key)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%v / %m</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>All entries are already translated.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Apply Results</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Batch Machine Translate</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Cancel Translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Cancelling…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Done. %d translated, %d errors.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Engine:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Mark results as fuzzy / needs work</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Nothing to Translate</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pending</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source language:</source>
            <translation>源语言：</translation>
        </message>
        <message>
            <source>Status</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target language:</source>
            <translation>目标语言：</translation>
        </message>
        <message>
            <source>Translate All</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translating…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation</source>
            <translation>翻译</translation>
        </message>
        <message>
            <source>Translation Settings</source>
            <translation>翻译设置</translation>
        </message>
        <message>
            <source>%d min %d s remaining</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d of %d strings · %.1f strings/s · %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d of %d strings · %.1f strings/s · %s remaining</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d s remaining</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;%d&lt;/b&gt; untranslated strings out of &lt;b&gt;%d&lt;/b&gt; total.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Completed %d strings in %d s</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>CollapsibleSidePanel</name>
        <message>
            <source>Ctx</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Info</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pre</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Ref</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TM</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Toggle side panel</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>ConcordanceDialog</name>
        <message>
            <source>Concordance Search</source>
            <translation>语料搜索</translation>
        </message>
        <message>
            <source>Double-click a row to copy translation to clipboard.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter word or phrase to search in TM…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Score</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation</source>
            <translation>翻译</translation>
        </message>
        <message>
            <source>Translation copied to clipboard.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>{} results found for </source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>ContextPanel</name>
        <message>
            <source>&lt;i&gt;MT unavailable&lt;/i&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;No matches&lt;/i&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;No matching terms&lt;/i&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;No suggestion&lt;/i&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Context</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Glossary</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Machine Translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Memory</source>
            <translation>翻译记忆</translation>
        </message>
        <message>
            <source>Source: %s\nTarget: %s</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>DashboardDialog</name>
        <message>
            <source>CSV files (*.csv)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Complete</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Statistics as CSV</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export as CSV…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>F:%d U:%d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fuzzy</source>
            <translation>模糊</translation>
        </message>
        <message>
            <source>Per-Language Progress</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Project Dashboard</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Statistics exported to %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translated</source>
            <translation>已翻译</translation>
        </message>
        <message>
            <source>Untranslated</source>
            <translation>未翻译</translation>
        </message>
        <message>
            <source>&lt;h2&gt;Project Overview&lt;/h2&gt;&lt;b&gt;Total strings:&lt;/b&gt; %d &amp;nbsp; &lt;span style=&apos;color:green&apos;&gt;Translated: %d&lt;/span&gt; &amp;nbsp; &lt;span style=&apos;color:orange&apos;&gt;Fuzzy: %d&lt;/span&gt; &amp;nbsp; &lt;span style=&apos;color:red&apos;&gt;Untranslated: %d&lt;/span&gt;</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>DiffDialog</name>
        <message>
            <source>Added Only</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Added:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>All Changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Browse...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Change</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Compare Files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Compare Translation Files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparison</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparison File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparison File:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparison Options</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparison Statistics</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparison complete. %d changes found.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparison failed: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to load file: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Ignore case</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Ignore whitespace</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Modified Only</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Modified:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No file selected</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Original</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Original File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Original File:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Removed Only</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Removed:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select Files to Compare</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select Translation File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Show unchanged</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Show:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Side by Side</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source Text</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Summary</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total entries:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation files (*.po *.pot *.ts *.json *.xliff *.xlf);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unchanged:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unsupported file format: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation: %s</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>FFmpegMissingDialog</name>
        <message>
            <source>Cancel</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Browse for ffmpeg…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>The selected file does not appear to be ffmpeg.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Not Found</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>FFmpeg Required</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>FFmpeg could still not be found in the system path.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Retry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Installation Instructions</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Could not run the selected file.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Executable files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Invalid File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select ffmpeg binary</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open Download Page</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Ubuntu/Debian:&lt;/b&gt;&lt;br&gt;&lt;code&gt;sudo apt install ffmpeg&lt;/code&gt;&lt;br&gt;&lt;br&gt;&lt;b&gt;Fedora:&lt;/b&gt;&lt;br&gt;&lt;code&gt;sudo dnf install ffmpeg&lt;/code&gt;&lt;br&gt;&lt;br&gt;&lt;b&gt;Arch Linux:&lt;/b&gt;&lt;br&gt;&lt;code&gt;sudo pacman -S ffmpeg&lt;/code&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;macOS (Homebrew):&lt;/b&gt;&lt;br&gt;&lt;code&gt;brew install ffmpeg&lt;/code&gt;&lt;br&gt;&lt;br&gt;&lt;b&gt;macOS (MacPorts):&lt;/b&gt;&lt;br&gt;&lt;code&gt;sudo port install ffmpeg&lt;/code&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;h3&gt;FFmpeg could not be found&lt;/h3&gt;&lt;p&gt;LinguaEdit needs &lt;b&gt;ffmpeg&lt;/b&gt; and &lt;b&gt;ffprobe&lt;/b&gt; to extract subtitles from video files.&lt;/p&gt;</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>FileHistoryDialog</name>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Date/Time</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Entry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Field</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File History</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Recent changes in: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Summary</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unknown</source>
            <translation>未知</translation>
        </message>
        <message>
            <source>User</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>View Entry History</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>GitDiffDialog</name>
        <message>
            <source>&lt;b&gt;Added strings:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Changed source text:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Changed translations:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Potentially outdated:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Removed strings:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;h3&gt;Comparison Results&lt;/h3&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Added</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Compare</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Compare with commit:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparing %d old vs %d current entries…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comparison complete.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Could not parse old version</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Diff with Previous Version</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to get file at commit %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Modified</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>New Source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No git history found</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Old Source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Outdated</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Removed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source (new)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source (old)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source changed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Status</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Summary</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation</source>
            <translation>翻译</translation>
        </message>
        <message>
            <source>Translation (new)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation (old)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Type</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>⚠ Outdated</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Outdated translations&lt;/b&gt; — source changed but translation stayed the same.</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>GlossaryDialog</name>
        <message>
            <source>%d terms</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>A term with this source text already exists. Update it?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Add</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>All domains</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>CSV Import Format</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>CSV files (*.csv);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Clear</source>
            <translation>清除</translation>
        </message>
        <message>
            <source>Confirm Delete</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copy Source</source>
            <translation>复制源文本</translation>
        </message>
        <message>
            <source>Copy Target</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Delete</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Delete term </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Domain</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Domain:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Duplicate Term</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Edit</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Edit Term</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Expected CSV format:\nsource,target,notes,domain\n\n</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export CSV...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Completed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Glossary to CSV</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Exported %d terms to %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to export glossary:\n%s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Glossary Management</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import CSV...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import Completed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import Glossary from CSV</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Imported %d terms with %d errors.\n\nFirst errors:\n%s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No terms to export.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Notes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Notes:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search &amp; Filter</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search in source or target...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Showing %d of %d terms</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source text cannot be empty.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Successfully imported %d terms.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target text cannot be empty.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Terms</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Update</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Warning</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Delete term &apos;%s&apos; → &apos;%s&apos;?</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>HeaderDialog</name>
        <message>
            <source>Additional Metadata</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Charset:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comment:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Content-Transfer-Encoding:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Data Type:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Define how plural forms work for this language.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Description:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Edit File Header</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>English (2 forms)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File Metadata</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Germanic (2 forms)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Language-Team:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Language:</source>
            <translation>语言：</translation>
        </message>
        <message>
            <source>Last-Translator:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Metadata</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Original File:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>PO Headers</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>PO-Revision-Date:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>POT-Creation-Date:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Package:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Plural Forms</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Project Information</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Project Name:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Project-Id-Version:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Report-Msgid-Bugs-To:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Restore Defaults</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Restore all fields to default values?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Romance (2 forms)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source Language:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TS Attributes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TS File Attributes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TS Version:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target Language:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Technical Information</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tool ID:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tool Information</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tool Name:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tool Version:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Information</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translator:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Version:</source>
            <translation>版本：</translation>
        </message>
        <message>
            <source>XLIFF Attributes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>XLIFF File Attributes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>XLIFF Version:</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>HistoryDialog</name>
        <message>
            <source>Added</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>After:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Before:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Change History</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Change Type</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Confirm Rollback</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Date/Time</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Deleted</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Diff:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Field</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>History for entry {0} in {1}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Modified</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No history available</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Rollback to This Version</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select a history entry to see changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation History</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unknown</source>
            <translation>未知</translation>
        </message>
        <message>
            <source>User</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Are you sure you want to rollback to this version?\n\nThis will replace the current text with:\n{}</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>ImagePreviewLabel</name>
        <message>
            <source>Click to select image\n(PNG, JPG, GIF)</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>LayoutSimulatorDialog</name>
        <message>
            <source>Bold</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Dialog Button</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Font Family:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Font Settings</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Highlight Overflow</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Layout Simulator</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Max Width:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Menu Item</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Mobile Button</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Presets:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Size (pt):</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source Text:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source: {0}px | Translation: {1}px | Difference: {2}px ({3:.1f}%)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tablet</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Text Comparison</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Text:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Width Constraints</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>LinguaEditWindow</name>
        <message>
            <source> ⚠ long</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source> ⚠ short</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d matches</source>
            <translation>%d 个匹配</translation>
        </message>
        <message>
            <source>%d strings</source>
            <translation>%d 个字符串</translation>
        </message>
        <message>
            <source>%d strings — %d translated, %d fuzzy, %d untranslated</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d translations applied</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%p% translated</source>
            <translation>%p% 已翻译</translation>
        </message>
        <message>
            <source>&amp;Catalog</source>
            <translation>目录(&amp;C)</translation>
        </message>
        <message>
            <source>&amp;Edit</source>
            <translation>编辑(&amp;E)</translation>
        </message>
        <message>
            <source>&amp;File</source>
            <translation>文件(&amp;F)</translation>
        </message>
        <message>
            <source>&amp;Git</source>
            <translation>&amp;Git</translation>
        </message>
        <message>
            <source>&amp;Go</source>
            <translation>转到(&amp;G)</translation>
        </message>
        <message>
            <source>&amp;Help</source>
            <translation>帮助(&amp;H)</translation>
        </message>
        <message>
            <source>&amp;Open…</source>
            <translation>打开(&amp;O)…</translation>
        </message>
        <message>
            <source>&amp;Platforms</source>
            <translation>平台(&amp;P)</translation>
        </message>
        <message>
            <source>&amp;Save</source>
            <translation>保存(&amp;S)</translation>
        </message>
        <message>
            <source>&amp;Tools</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&amp;View</source>
            <translation>视图(&amp;V)</translation>
        </message>
        <message>
            <source>&lt;b&gt;Concordance search&lt;/b&gt;</source>
            <translation>&lt;b&gt;语料搜索&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Reference source:&lt;/b&gt;</source>
            <translation>&lt;b&gt;参考源文本：&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Reference translation:&lt;/b&gt;</source>
            <translation>&lt;b&gt;参考翻译：&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Source text:&lt;/b&gt;</source>
            <translation>&lt;b&gt;源文本：&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Suggestions&lt;/b&gt;</source>
            <translation>&lt;b&gt;建议&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Translation:&lt;/b&gt;</source>
            <translation>&lt;b&gt;翻译：&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Translator comment:&lt;/b&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;(no match in reference)&lt;/i&gt;</source>
            <translation>&lt;i&gt;（参考中无匹配）&lt;/i&gt;</translation>
        </message>
        <message>
            <source>&lt;i&gt;No suggestions&lt;/i&gt;</source>
            <translation>&lt;i&gt;无建议&lt;/i&gt;</translation>
        </message>
        <message>
            <source>A macro with this name already exists.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>A translation file editor for PO, TS, JSON, XLIFF, </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>A translation file is currently open with unsaved changes.\n</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>AI Review</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>API Keys</source>
            <translation>API 密钥</translation>
        </message>
        <message>
            <source>API keys saved</source>
            <translation>API 密钥已保存</translation>
        </message>
        <message>
            <source>About LinguaEdit</source>
            <translation>关于 LinguaEdit</translation>
        </message>
        <message>
            <source>About Qt</source>
            <translation>关于 Qt</translation>
        </message>
        <message>
            <source>Achievements…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Add Bookmark</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Add Comment</source>
            <translation>添加评论</translation>
        </message>
        <message>
            <source>Add Field</source>
            <translation>添加字段</translation>
        </message>
        <message>
            <source>Add Tag</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Add Tag...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Add Term</source>
            <translation>添加术语</translation>
        </message>
        <message>
            <source>Add translator notes...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Added %d entries to Translation Memory</source>
            <translation>已向翻译记忆添加 %d 条</translation>
        </message>
        <message>
            <source>Added: %s → %s</source>
            <translation>已添加：%s → %s</translation>
        </message>
        <message>
            <source>All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>All strings</source>
            <translation>所有字符串</translation>
        </message>
        <message>
            <source>Already recording a macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Applied changes to %d entries</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Apply Machine Translation suggestion</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Apply best Translation Memory match</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Approve</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Attach current file</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Auto-compile enabled</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Auto-compiled after save</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Auto-propagate</source>
            <translation>自动传播</translation>
        </message>
        <message>
            <source>Auto-propagated %d entries</source>
            <translation>已自动传播 %d 条</translation>
        </message>
        <message>
            <source>Batch Edit…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Batch Translate…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Bilingual export (source + translation)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Bookmark added</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Bookmark removed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>By length</source>
            <translation>按长度</translation>
        </message>
        <message>
            <source>By reference</source>
            <translation>按参考</translation>
        </message>
        <message>
            <source>Cancel</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Cannot compile: install </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Cannot compile: pyside6-lrelease or lrelease not found</source>
            <translation>无法编译：未找到 pyside6-lrelease 或 lrelease</translation>
        </message>
        <message>
            <source>Cannot split empty entry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Category</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Changes committed locally</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Changes pushed successfully</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Check for updates</source>
            <translation>检查更新</translation>
        </message>
        <message>
            <source>Clear</source>
            <translation>清除</translation>
        </message>
        <message>
            <source>Clear translation</source>
            <translation>清除翻译</translation>
        </message>
        <message>
            <source>Close Current File?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close Tab</source>
            <translation>关闭标签页</translation>
        </message>
        <message>
            <source>Close the current file and load extracted subtitles?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Comments</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Commit failed: %s</source>
            <translation>提交失败：%s</translation>
        </message>
        <message>
            <source>Commit message:</source>
            <translation>提交信息：</translation>
        </message>
        <message>
            <source>Commit successful. Push to remote?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Committed!</source>
            <translation>已提交！</translation>
        </message>
        <message>
            <source>Commit…</source>
            <translation>提交…</translation>
        </message>
        <message>
            <source>Compare Files…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Compare language…</source>
            <translation>比较语言…</translation>
        </message>
        <message>
            <source>Compile</source>
            <translation>编译</translation>
        </message>
        <message>
            <source>Compile error: %s</source>
            <translation>编译错误：%s</translation>
        </message>
        <message>
            <source>Compile not supported for %s files</source>
            <translation>不支持编译 %s 文件</translation>
        </message>
        <message>
            <source>Compile translation</source>
            <translation>编译翻译</translation>
        </message>
        <message>
            <source>Compiled: %s</source>
            <translation>已编译：%s</translation>
        </message>
        <message>
            <source>Concordance</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Concordance Search…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Consistency Check</source>
            <translation>一致性检查</translation>
        </message>
        <message>
            <source>Consistency check</source>
            <translation>一致性检查</translation>
        </message>
        <message>
            <source>Context</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copy Source</source>
            <translation>复制源文本</translation>
        </message>
        <message>
            <source>Copy source</source>
            <translation>复制源文本</translation>
        </message>
        <message>
            <source>Copy source text to translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copy source text to translation (Ctrl+B)</source>
            <translation>复制源文本到翻译 (Ctrl+B)</translation>
        </message>
        <message>
            <source>Copy source to translation</source>
            <translation>复制源文本到翻译</translation>
        </message>
        <message>
            <source>Could not read video file:\n%s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Count</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Crowdin</source>
            <translation>Crowdin</translation>
        </message>
        <message>
            <source>Crowdin Statistics…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Crowdin Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No Crowdin API key configured.\nPlease add one in Translation → API Keys…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Crowdin — %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translated: %d%% (%d/%d)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Approved: %d%% (%d/%d)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pull Translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Push Source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Current string has no translation to propagate.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Customize Toolbar…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Dark</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Date</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Developer</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Developer:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Diff</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Diff with Previous Version…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Diff…</source>
            <translation>差异…</translation>
        </message>
        <message>
            <source>Documentation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Donate ♥</source>
            <translation>捐赠 ♥</translation>
        </message>
        <message>
            <source>Done and next (Ctrl+Enter)</source>
            <translation>完成并下一条 (Ctrl+Enter)</translation>
        </message>
        <message>
            <source>Edit Header…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Edit file header metadata. Changes are applied when you click Save.</source>
            <translation>编辑文件头元数据。更改将在点击保存时应用。</translation>
        </message>
        <message>
            <source>Editor Below</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Editor on Right</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Email Translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Email Translation…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Email client opened</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter macro name:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter translator note:</source>
            <translation>输入译者备注：</translation>
        </message>
        <message>
            <source>Entry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Entry pinned</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Entry split into 2 segments</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Entry unpinned</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error loading file: %s</source>
            <translation>加载文件错误：%s</translation>
        </message>
        <message>
            <source>Error loading reference: %s</source>
            <translation>加载参考错误：%s</translation>
        </message>
        <message>
            <source>Export Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export TMX</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export TMX…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export report…</source>
            <translation>导出报告…</translation>
        </message>
        <message>
            <source>Exported {} translation units to {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extract Subtitles from Video…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extracting</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extracting subtitles…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extraction Failed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to export TMX file: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to import TMX file: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to play macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to run msgmerge:\n{}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Feed file to TM</source>
            <translation>将文件添加到翻译记忆</translation>
        </message>
        <message>
            <source>File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File Changed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File Header / Metadata</source>
            <translation>文件头 / 元数据</translation>
        </message>
        <message>
            <source>File metadata…</source>
            <translation>文件元数据…</translation>
        </message>
        <message>
            <source>File not found: %s</source>
            <translation>文件未找到：%s</translation>
        </message>
        <message>
            <source>File order</source>
            <translation>文件顺序</translation>
        </message>
        <message>
            <source>File reloaded (changed externally)</source>
            <translation>文件已重新加载（外部更改）</translation>
        </message>
        <message>
            <source>File reloaded (external change detected)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find &amp;&amp; Replace…</source>
            <translation>查找和替换…</translation>
        </message>
        <message>
            <source>Find in translations…</source>
            <translation>在翻译中查找…</translation>
        </message>
        <message>
            <source>Find…</source>
            <translation>查找…</translation>
        </message>
        <message>
            <source>Flags</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Focus Mode</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Focus mode disabled</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Focus mode enabled - hiding completed translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Format:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Found %d subtitle track(s). Select one:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fullscreen</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fullscreen mode - Press Escape to exit</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fuzzy</source>
            <translation>模糊</translation>
        </message>
        <message>
            <source>Fuzzy / Needs work</source>
            <translation>模糊 / 需要修改</translation>
        </message>
        <message>
            <source>Fuzzy diff (previous → current)</source>
            <translation>模糊差异（上一版 → 当前）</translation>
        </message>
        <message>
            <source>Fuzzy:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fuzzy: %d</source>
            <translation>模糊：%d</translation>
        </message>
        <message>
            <source>Fuzzy: 0</source>
            <translation>模糊：0</translation>
        </message>
        <message>
            <source>Generate Report</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Generate Report…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Generated by LinguaEdit</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Git</source>
            <translation>Git</translation>
        </message>
        <message>
            <source>Git Branches</source>
            <translation>Git 分支</translation>
        </message>
        <message>
            <source>Git Commit</source>
            <translation>Git 提交</translation>
        </message>
        <message>
            <source>Git Diff</source>
            <translation>Git 差异</translation>
        </message>
        <message>
            <source>Git Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Git Status</source>
            <translation>Git 状态</translation>
        </message>
        <message>
            <source>Git operation error: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Git operation failed: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>GitHub PR</source>
            <translation>GitHub PR</translation>
        </message>
        <message>
            <source>GitHub PR…</source>
            <translation>GitHub PR…</translation>
        </message>
        <message>
            <source>GitHub Repository</source>
            <translation>GitHub 仓库</translation>
        </message>
        <message>
            <source>Glossary</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Glossary / Terminology</source>
            <translation>术语表 / 术语</translation>
        </message>
        <message>
            <source>Glossary Check</source>
            <translation>术语检查</translation>
        </message>
        <message>
            <source>Glossary…</source>
            <translation>术语表…</translation>
        </message>
        <message>
            <source>HTML (*.html);;PDF (*.pdf)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>HTML files (*.html);;PDF files (*.pdf)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Header updated</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import TMX</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import TMX…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Imported {} translation units</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Include fuzzy entries</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Incomplete Subtitles</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Invalid regex</source>
            <translation>无效的正则表达式</translation>
        </message>
        <message>
            <source>Issues</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>JSON files (*.json);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Key</source>
            <translation>键</translation>
        </message>
        <message>
            <source>Language</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Language:</source>
            <translation>语言：</translation>
        </message>
        <message>
            <source>Languages</source>
            <translation>语言</translation>
        </message>
        <message>
            <source>Layout Simulator</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>License:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Light</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>LinguaEdit</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Ln %d, Col %d</source>
            <translation>行 %d，列 %d</translation>
        </message>
        <message>
            <source>Ln 1, Col 1</source>
            <translation>行 1，列 1</translation>
        </message>
        <message>
            <source>Loaded reference: %s</source>
            <translation>已加载参考：%s</translation>
        </message>
        <message>
            <source>Locale:</source>
            <translation>区域设置：</translation>
        </message>
        <message>
            <source>MT translation failed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macro Exists</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macros</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Main</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Manage API Keys…</source>
            <translation>管理 API 密钥…</translation>
        </message>
        <message>
            <source>Manage Macros…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Manage Plugins…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Mark current entry as reviewed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Mark this string as fuzzy / needs review (Ctrl+U)</source>
            <translation>标记此字符串为模糊 / 需要审查 (Ctrl+U)</translation>
        </message>
        <message>
            <source>Max width:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Merge Entries…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Merge with POT…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Merged {} entries</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Message</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Message:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Metadata updated</source>
            <translation>元数据已更新</translation>
        </message>
        <message>
            <source>Minimap</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Monokai</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Msgmerge Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Msgmerge Not Found</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Needs Review</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Needs work</source>
            <translation>需要修改</translation>
        </message>
        <message>
            <source>Next</source>
            <translation>下一步</translation>
        </message>
        <message>
            <source>Next entry</source>
            <translation>下一条</translation>
        </message>
        <message>
            <source>Next untranslated</source>
            <translation>下一个未翻译</translation>
        </message>
        <message>
            <source>No File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No Subtitles</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No bookmarks set</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No embedded subtitle tracks found in this video file.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No enabled macros</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No file</source>
            <translation>无文件</translation>
        </message>
        <message>
            <source>No file loaded</source>
            <translation>未加载文件</translation>
        </message>
        <message>
            <source>No glossary violations found! ✓</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No identical source strings found.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No inconsistencies found! ✓</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No issues found</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No macros available</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No more fuzzy strings</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No more untranslated strings</source>
            <translation>没有更多未翻译的字符串</translation>
        </message>
        <message>
            <source>No screenshot available</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No source text to review</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No terms defined</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No text to check</source>
            <translation>没有文本可检查</translation>
        </message>
        <message>
            <source>No text to play</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No translation selected</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No translation to preview</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Nord</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Normal Mode</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Normal sorting order</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Not a git repository</source>
            <translation>不是 Git 仓库</translation>
        </message>
        <message>
            <source>Notes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OCR Screenshot…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OCR extraction completed. {} strings extracted.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open</source>
            <translation>打开</translation>
        </message>
        <message>
            <source>Open Project…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open Reference File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open Translation File</source>
            <translation>打开翻译文件</translation>
        </message>
        <message>
            <source>Open Video</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open Video…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Options</source>
            <translation>选项</translation>
        </message>
        <message>
            <source>PO file merged successfully with POT file.\nPlease reload the file to see changes.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>PO files (*.po);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>POT Files (*.pot)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Platform settings…</source>
            <translation>平台设置…</translation>
        </message>
        <message>
            <source>Play Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Play Translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Playing translation...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Please enter recipient email</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Please open a PO file first.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Plural: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pre-translate</source>
            <translation>预翻译</translation>
        </message>
        <message>
            <source>Pre-translated %d entries via %s</source>
            <translation>通过 %s 预翻译了 %d 条</translation>
        </message>
        <message>
            <source>Pre-translate…</source>
            <translation>预翻译…</translation>
        </message>
        <message>
            <source>Preferences…</source>
            <translation>首选项…</translation>
        </message>
        <message>
            <source>Preview</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Previous</source>
            <translation>上一个</translation>
        </message>
        <message>
            <source>Previous entry</source>
            <translation>上一条</translation>
        </message>
        <message>
            <source>Previous untranslated</source>
            <translation>上一个未翻译</translation>
        </message>
        <message>
            <source>Probing video for subtitle tracks…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Project Dashboard</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Propagate Translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pull Latest</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pull from…</source>
            <translation>从…拉取</translation>
        </message>
        <message>
            <source>Push Changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Push to…</source>
            <translation>推送到…</translation>
        </message>
        <message>
            <source>QA Profile: %s</source>
            <translation>QA 配置：%s</translation>
        </message>
        <message>
            <source>QA profile: Formal</source>
            <translation>QA 配置：正式</translation>
        </message>
        <message>
            <source>QA profile: Informal</source>
            <translation>QA 配置：非正式</translation>
        </message>
        <message>
            <source>Quality</source>
            <translation>质量</translation>
        </message>
        <message>
            <source>Quality Score</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Quit</source>
            <translation>退出</translation>
        </message>
        <message>
            <source>Recent Files</source>
            <translation>最近的文件</translation>
        </message>
        <message>
            <source>Record Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Recording macro </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Redo</source>
            <translation>重做</translation>
        </message>
        <message>
            <source>Reference</source>
            <translation>参考</translation>
        </message>
        <message>
            <source>References</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Regex</source>
            <translation>正则表达式</translation>
        </message>
        <message>
            <source>Regex Tester</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Reject</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Remove Bookmark</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Remove Selected</source>
            <translation>删除所选</translation>
        </message>
        <message>
            <source>Replace</source>
            <translation>替换</translation>
        </message>
        <message>
            <source>Replace All</source>
            <translation>全部替换</translation>
        </message>
        <message>
            <source>Replace with…</source>
            <translation>替换为…</translation>
        </message>
        <message>
            <source>Replaced in %d entries</source>
            <translation>在 %d 条中替换</translation>
        </message>
        <message>
            <source>Report Options</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Report a Bug</source>
            <translation>报告错误</translation>
        </message>
        <message>
            <source>Report error: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Report saved</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Report saved to %s</source>
            <translation>报告已保存到 %s</translation>
        </message>
        <message>
            <source>Report saved: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Review</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Review Mode</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Review mode disabled</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Review mode enabled</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Reviewed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Root key:</source>
            <translation>根键：</translation>
        </message>
        <message>
            <source>SRT files (*.srt);;VTT files (*.vtt);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Save</source>
            <translation>保存</translation>
        </message>
        <message>
            <source>Save &amp;As…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Save As…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Save Current File?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Save Extracted Subtitles</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Save Report</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Save error: %s</source>
            <translation>保存错误：%s</translation>
        </message>
        <message>
            <source>Saved as %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Saved!</source>
            <translation>已保存！</translation>
        </message>
        <message>
            <source>Search</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search TM…</source>
            <translation>搜索翻译记忆…</translation>
        </message>
        <message>
            <source>Search source and translation text…</source>
            <translation>搜索源文本和翻译…</translation>
        </message>
        <message>
            <source>Select POT File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select Subtitle Track</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select at least 2 entries to merge</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select macro to play:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select or enter tag:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Settings</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Severity</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Show Bookmarked Only</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Show Pinned First</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Showing all entries</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Showing only bookmarked entries</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Showing pinned entries first</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Side-by-Side View</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Sidebar</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Simple Mode</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Solarized Dark</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source A → Z</source>
            <translation>源文本 A → Z</translation>
        </message>
        <message>
            <source>Source Z → A</source>
            <translation>源文本 Z → A</translation>
        </message>
        <message>
            <source>Source language:</source>
            <translation>源语言：</translation>
        </message>
        <message>
            <source>Source term:</source>
            <translation>源术语：</translation>
        </message>
        <message>
            <source>Source text</source>
            <translation>源文本</translation>
        </message>
        <message>
            <source>Source:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Spell check current</source>
            <translation>拼写检查当前</translation>
        </message>
        <message>
            <source>Spelling issues:\n%s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Split Entry…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Stacked View</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Statistics</source>
            <translation>统计</translation>
        </message>
        <message>
            <source>Statistics…</source>
            <translation>统计…</translation>
        </message>
        <message>
            <source>Status</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Status…</source>
            <translation>状态…</translation>
        </message>
        <message>
            <source>String Info</source>
            <translation>字符串信息</translation>
        </message>
        <message>
            <source>Subject:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Success</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Summary by Category</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Switch branch…</source>
            <translation>切换分支…</translation>
        </message>
        <message>
            <source>System Default</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TM / Suggestions</source>
            <translation>翻译记忆 / 建议</translation>
        </message>
        <message>
            <source>TMX</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TMX Export</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TMX Files (*.tmx)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TMX Import</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TS files (*.ts);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TTS Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tag filter removed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tags</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target language:</source>
            <translation>目标语言：</translation>
        </message>
        <message>
            <source>Target term:</source>
            <translation>目标术语：</translation>
        </message>
        <message>
            <source>Text-to-speech failed: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>The current file has unsaved changes.\nDo you want to save before continuing?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>The file </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>The file has been changed externally. Reload?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Theme</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Theme changed to %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>This feature only works with PO files.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Time interval</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Time:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>To:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Toggle fuzzy/needs work flag</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total entries:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Transifex</source>
            <translation>Transifex</translation>
        </message>
        <message>
            <source>Translated</source>
            <translation>已翻译</translation>
        </message>
        <message>
            <source>Translated via %s</source>
            <translation>通过 %s 翻译</translation>
        </message>
        <message>
            <source>Translated:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translated: %d</source>
            <translation>已翻译：%d</translation>
        </message>
        <message>
            <source>Translated: 0</source>
            <translation>已翻译：0</translation>
        </message>
        <message>
            <source>Translation</source>
            <translation>翻译</translation>
        </message>
        <message>
            <source>Translation A → Z</source>
            <translation>翻译 A → Z</translation>
        </message>
        <message>
            <source>Translation Engine</source>
            <translation>翻译引擎</translation>
        </message>
        <message>
            <source>API key:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Auto-detect</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter API key</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Not required for free engines</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation History…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Map…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Report</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Z → A</source>
            <translation>翻译 Z → A</translation>
        </message>
        <message>
            <source>Translation preview will appear here</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation rolled back</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation updated from AI review</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Undo</source>
            <translation>撤销</translation>
        </message>
        <message>
            <source>Unicode Inspector</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unknown</source>
            <translation>未知</translation>
        </message>
        <message>
            <source>Unsaved Changes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unsupported file type: %s</source>
            <translation>不支持的文件类型：%s</translation>
        </message>
        <message>
            <source>Untitled</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Untranslated</source>
            <translation>未翻译</translation>
        </message>
        <message>
            <source>Untranslated/errors first</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Untranslated:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Untranslated: %d</source>
            <translation>未翻译：%d</translation>
        </message>
        <message>
            <source>Untranslated: 0</source>
            <translation>未翻译：0</translation>
        </message>
        <message>
            <source>Up to date</source>
            <translation>已是最新</translation>
        </message>
        <message>
            <source>Update Available</source>
            <translation>有可用更新</translation>
        </message>
        <message>
            <source>Updated {} translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Validate</source>
            <translation>验证</translation>
        </message>
        <message>
            <source>Validate (Lint)</source>
            <translation>验证 (Lint)</translation>
        </message>
        <message>
            <source>Value</source>
            <translation>值</translation>
        </message>
        <message>
            <source>Version:</source>
            <translation>版本：</translation>
        </message>
        <message>
            <source>Video</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Video file</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Video files (*.mkv *.mp4 *.avi *.mov *.webm *.flv *.wmv *.ogv);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Warnings</source>
            <translation>警告</translation>
        </message>
        <message>
            <source>Watch File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Watch mode disabled</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Watch mode enabled - file changes will be detected</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Weblate</source>
            <translation>Weblate</translation>
        </message>
        <message>
            <source>Website:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>With warnings</source>
            <translation>有警告</translation>
        </message>
        <message>
            <source>Words: %d | Chars: %d | Source: %dw%s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Would you like to extract subtitles from this video?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Wrong File Type</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>XLIFF files (*.xlf *.xliff);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Zen Mode</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>\n\nErrors:\n{}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>lrelease error: %s</source>
            <translation>lrelease 错误：%s</translation>
        </message>
        <message>
            <source>msgfmt error: %s</source>
            <translation>msgfmt 错误：%s</translation>
        </message>
        <message>
            <source>msgmerge command not found. Please install gettext tools.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>msgmerge failed:\n{}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>translated</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>words</source>
            <translation>词</translation>
        </message>
        <message>
            <source>{} chars | {} words | Source: {} chars</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>… and %d more</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>⚠️ Toggle Fuzzy</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>✅ Mark Reviewed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>✓ No spelling issues found</source>
            <translation>✓ 未发现拼写问题</translation>
        </message>
        <message>
            <source>💬 Comment</source>
            <translation>💬 评论</translation>
        </message>
        <message>
            <source>💾 Apply TM #1</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>📋 Copy Source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>📌 Pin Entry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>📌 Unpin Entry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>🔊 Play Translation</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>🤖 Apply MT</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>DeepL formality:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OpenAI model:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Anthropic model:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>MS Azure region:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>AWS Secret Key:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>AWS Region:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>ID: %1</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>State: %1</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation: %1</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d min %d s remaining</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d of %d entries (%d%%) have no translation.\n\nUntranslated entries will be marked and saved with the source text as fallback, so they will still display during playback. When reopened in LinguaEdit, they will be correctly shown as untranslated.\n\nSave anyway?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d of %d strings · %.1f strings/s · %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d of %d strings · %.1f strings/s · %s remaining</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d s remaining</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;p&gt;LinguaEdit is free software.&lt;/p&gt;&lt;p&gt;If you find it useful, consider supporting development:&lt;/p&gt;&lt;p&gt;❤️ &lt;b&gt;GitHub Sponsors:&lt;/b&gt; &lt;a href=&apos;https://github.com/sponsors/yeager&apos;&gt;github.com/sponsors/yeager&lt;/a&gt;&lt;/p&gt;&lt;p&gt;🇸🇪 &lt;b&gt;Swish:&lt;/b&gt; +46702526206 — &lt;a href=&apos;swish://payment?payee=0702526206&amp;message=LinguaEdit&apos;&gt;Öppna Swish&lt;/a&gt;&lt;/p&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Cannot compile: install &apos;polib&apos; or &apos;gettext&apos; (msgfmt)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No untranslated entries</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pre-translated %d entries via %s (%d errors)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pre-translated %d entries via %s (%d errors — last: %s)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pre-translated %d of %d entries via %s (cancelled)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pre-translated %d of %d entries via %s (cancelled, %d errors — last: %s)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pre-translate cancelled — no translations made</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pre-translating…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error translating string %d of %d:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Skip All Errors</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Continue</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Stop</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Recording macro &apos;{}&apos;...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>The file &apos;%s&apos; has unsaved changes.\nDo you want to save before closing?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>LinguaEdit — %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Backend: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source: \&quot;%s\&quot;\n  Entries: %s\n  Translations: %s\n</source>
            <translation type="unfinished"/>
        </message>
    <message>
            <source>Source: %s\nTarget: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%s\n\nAdd a new term or check file?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File: %s\nEntries: %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Found %d inconsistencies:\n\n</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Weblate Statistics…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No Weblate API key or server URL configured.\nPlease add them in Translation → API Keys…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Weblate Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Weblate</source>
            <translation>Weblate</translation>
        </message>
        <message>
            <source>Weblate — %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>  (fuzzy: %d)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Weblate Server URL:</source>
            <translation type="unfinished"/>
        </message>
    <message><source>No API Key</source><translation type="unfinished"/></message><message><source>No Transifex API key configured.
Please add one in Translation → API Keys…</source><translation type="unfinished"/></message><message><source>No language statistics found.</source><translation type="unfinished"/></message><message><source>No organizations found.</source><translation type="unfinished"/></message><message><source>No projects found.</source><translation type="unfinished"/></message><message><source>Organization:</source><translation>组织：</translation></message><message><source>Project:</source><translation>项目：</translation></message><message><source>Select Organization</source><translation type="unfinished"/></message><message><source>Select Project</source><translation type="unfinished"/></message><message><source>Transifex Error</source><translation type="unfinished"/></message><message><source>Transifex Statistics…</source><translation type="unfinished"/></message><message><source>Transifex — %s</source><translation type="unfinished"/></message><message><source>Translation statistics for &lt;b&gt;%s&lt;/b&gt;:</source><translation type="unfinished"/></message></context>
    <context>
        <name>Linter</name>
        <message>
            <source>Accelerator key mismatch: source has %d, translation has %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Case mismatch: source starts with </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Ending </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extra HTML/XML tags in translation: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Format specifier mismatch: %s vs %s</source>
            <translation>格式说明符不匹配：%s 对 %s</translation>
        </message>
        <message>
            <source>Fuzzy</source>
            <translation>模糊</translation>
        </message>
        <message>
            <source>Glossary inconsistency: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Inconsistent translation for </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Leading whitespace mismatch</source>
            <translation>前导空白不匹配</translation>
        </message>
        <message>
            <source>Missing HTML/XML tags in translation: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Newline count mismatch (%s vs %s)</source>
            <translation>换行数不匹配（%s 对 %s）</translation>
        </message>
        <message>
            <source>Python format mismatch: %s vs %s</source>
            <translation>Python 格式不匹配：%s 对 %s</translation>
        </message>
        <message>
            <source>Suspicious length ratio: %sx</source>
            <translation>可疑的长度比：%sx</translation>
        </message>
        <message>
            <source>Trailing whitespace mismatch</source>
            <translation>尾随空白不匹配</translation>
        </message>
        <message>
            <source>Untranslated</source>
            <translation>未翻译</translation>
        </message>
    </context>
    <context>
        <name>LocaleMapDialog</name>
        <message>
            <source>Average progress</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Browse...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Click on a country to see details</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Complete</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Countries with translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Country Details</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fuzzy</source>
            <translation>模糊</translation>
        </message>
        <message>
            <source>Locale Files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Minimal</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Missing</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No translation data</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No translation files found in project.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Partial</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Project Summary</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Project:</source>
            <translation>项目：</translation>
        </message>
        <message>
            <source>Refresh</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select Project Directory</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total strings</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translated</source>
            <translation>已翻译</translation>
        </message>
        <message>
            <source>Translation Map</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Progress by Region</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Statistics</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Would open: {}</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>MacroDialog</name>
        <message>
            <source>A macro with this name already exists. Please choose a different name.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Actions:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Are you sure you want to delete the macro </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Cannot find main window for macro playback.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Delete</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Delete Failed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Delete Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Description:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Disabled</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enabled:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter macro description (optional):</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter macro name:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter new name:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Failed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Export Successful</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to delete macro.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to export macro.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to export macro: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to import macro: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to play macro </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to rename macro. The new name may already exist.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to save the macro. No actions were recorded.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import Failed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Import Successful</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>JSON Files (*.json)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macro </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macro Description</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macro Details</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macro Exists</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macro Saved</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macro exported to {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macros</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Manage Macros</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Name:</source>
            <translation>姓名：</translation>
        </message>
        <message>
            <source>No actions recorded</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Play</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Playback Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Ready to record</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Record Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Record New Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Recording Failed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Rename</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Rename Failed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Rename Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Shortcut:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Stop Recording</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>🔴 Recording in progress...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>🔴 Recording... ({} actions)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Are you sure you want to delete the macro &apos;{}&apos;?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to play macro &apos;{}&apos;.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Macro &apos;{}&apos; has been saved successfully.</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>MergePreviewDialog</name>
        <message>
            <source>Merge Entries</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Original segments:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Preview of merged entry ({} segments):</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation:</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>MinimapWidget</name>
        <message>
            <source>Minimap – click to jump</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>OCRDialog</name>
        <message>
            <source>Apply image preprocessing to improve OCR accuracy</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Apply preprocessing</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Assume a single column of text of variable sizes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Assume a single uniform block of text</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Assume a single uniform block of vertically aligned text</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Automatic page segmentation with OSD</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Automatic page segmentation, but no OSD, or OCR</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Browse Image...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Could not load image.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Create PO from Extracted Strings</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extract Text</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extracted Text</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to create PO file:\n{}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Filter extracted strings...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Filter:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fully automatic page segmentation, but no OSD</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Image</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Image Files (*.png *.jpg *.jpeg *.gif *.bmp *.tiff)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Language:</source>
            <translation>语言：</translation>
        </message>
        <message>
            <source>No Strings</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No strings selected for PO file creation.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OCR Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OCR Screenshot</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OCR Settings</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Orientation and script detection (OSD) only</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>PO Files (*.po)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>PO file created successfully:\n{}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Page Segmentation:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Raw OCR Output</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Raw line. Treat the image as a single text line, bypassing hacks</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Remove Selected</source>
            <translation>删除所选</translation>
        </message>
        <message>
            <source>Save PO File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select All</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select Image</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select None</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Sparse text with OSD</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Sparse text. Find as much text as possible in no particular order</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Success</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tesseract Required</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Treat the image as a single character</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Treat the image as a single text line</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Treat the image as a single word</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Treat the image as a single word in a circle</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>✓ Tesseract available: %1</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Image loaded: %1</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>✓ OCR completed. Found %1 text strings.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>✗ OCR failed: %1</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OCR functionality requires tesseract-ocr to be installed.\n\nInstallation instructions:\n• macOS: brew install tesseract\n• Ubuntu/Debian: sudo apt install tesseract-ocr\n• Windows: Download from GitHub releases\n• Arch Linux: sudo pacman -S tesseract</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>⚠ No text found in image.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>⚠ Tesseract not found. Please install tesseract-ocr.</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>OCRWorker</name>
        <message>
            <source>Checking tesseract installation...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Processing image...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Tesseract not installed. Please install tesseract-ocr.</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>PlatformSettingsDialog</name>
        <message>
            <source>API Key:</source>
            <translation>API 密钥：</translation>
        </message>
        <message>
            <source>API Token:</source>
            <translation>API 令牌：</translation>
        </message>
        <message>
            <source>API URL:</source>
            <translation>API URL：</translation>
        </message>
        <message>
            <source>Base URL:</source>
            <translation>基础 URL：</translation>
        </message>
        <message>
            <source>Component:</source>
            <translation>组件：</translation>
        </message>
        <message>
            <source>Crowdin</source>
            <translation>Crowdin</translation>
        </message>
        <message>
            <source>Crowdin API</source>
            <translation>Crowdin API</translation>
        </message>
        <message>
            <source>Organization:</source>
            <translation>组织：</translation>
        </message>
        <message>
            <source>Platform Settings</source>
            <translation>平台设置</translation>
        </message>
        <message>
            <source>Project ID:</source>
            <translation>项目 ID：</translation>
        </message>
        <message>
            <source>Project:</source>
            <translation>项目：</translation>
        </message>
        <message>
            <source>Save</source>
            <translation>保存</translation>
        </message>
        <message>
            <source>Test Connection</source>
            <translation>测试连接</translation>
        </message>
        <message>
            <source>Testing…</source>
            <translation>测试中…</translation>
        </message>
        <message>
            <source>Transifex</source>
            <translation>Transifex</translation>
        </message>
        <message>
            <source>Transifex API</source>
            <translation>Transifex API</translation>
        </message>
        <message>
            <source>Weblate</source>
            <translation>Weblate</translation>
        </message>
        <message>
            <source>Weblate API</source>
            <translation>Weblate API</translation>
        </message>
        <message>
            <source>⚠️ No system keychain — tokens stored with basic obfuscation. </source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>✓ Connected: %1</source>
            <translation>✓ 已连接：%1</translation>
        </message>
        <message>
            <source>✓ Saved</source>
            <translation>✓ 已保存</translation>
        </message>
        <message>
            <source>✗ %1</source>
            <translation>✗ %1</translation>
        </message>
        <message>
            <source>✗ Project ID must be a number</source>
            <translation>✗ 项目 ID 必须是数字</translation>
        </message>
        <message>
            <source>🔒 Tokens stored in %1</source>
            <translation>🔒 令牌存储在 %1</translation>
        </message>
    </context>
    <context>
        <name>PluginDialog</name>
        <message>
            <source>All plugins have been reloaded successfully.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Author</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Author: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Disable</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enable</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enabled</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to reload plugins: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Installed Plugins</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Manage Plugins</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Name</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open Plugin Folder</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Plugin Details</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Plugins Reloaded</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Plugins are loaded from: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Reload Failed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Reload Plugins</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Version</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Version: {}</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>PluralFormsEditor</name>
        <message>
            <source>Plural rules</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Clear all</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Sync from singular</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>PreferencesDialog</name>
        <message>
            <source> characters</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Appearance</source>
            <translation>外观</translation>
        </message>
        <message>
            <source>Auto-compile on save</source>
            <translation>保存时自动编译</translation>
        </message>
        <message>
            <source>Automatically compile .mo/.qm after saving</source>
            <translation>保存后自动编译 .mo/.qm</translation>
        </message>
        <message>
            <source>Character limit:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Credential storage:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Dark</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Default</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Default engine:</source>
            <translation>默认引擎：</translation>
        </message>
        <message>
            <source>Double-click to edit translations directly in the list</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Editor font size:</source>
            <translation>编辑器字体大小：</translation>
        </message>
        <message>
            <source>Email:</source>
            <translation>电子邮件：</translation>
        </message>
        <message>
            <source>Enable inline editing</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Formal</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Formality level:</source>
            <translation>正式程度：</translation>
        </message>
        <message>
            <source>Informal</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Language / Locale:</source>
            <translation>语言 / 区域设置：</translation>
        </message>
        <message>
            <source>Light</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Name:</source>
            <translation>姓名：</translation>
        </message>
        <message>
            <source>Personal</source>
            <translation>个人</translation>
        </message>
        <message>
            <source>Preferences</source>
            <translation>首选项</translation>
        </message>
        <message>
            <source>Security</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Show character counter</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source language:</source>
            <translation>源语言：</translation>
        </message>
        <message>
            <source>System default</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target language:</source>
            <translation>目标语言：</translation>
        </message>
        <message>
            <source>Team:</source>
            <translation>团队：</translation>
        </message>
        <message>
            <source>Theme:</source>
            <translation>主题：</translation>
        </message>
        <message>
            <source>Translation</source>
            <translation>翻译</translation>
        </message>
        <message>
            <source>No system keychain detected. Credentials are stored in an encrypted file with a master password.\n\nFor better security, install:\n• macOS: Built-in (Keychain)\n• Windows: pip install keyring\n• Linux: pip install secretstorage</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Your credentials are securely stored in the system keychain.</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>ProjectDockWidget</name>
        <message>
            <source>All files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Analyzing project...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Avg:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Complete</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copy Path</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File Properties</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Files:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Filter:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Found %d translation files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Incomplete</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>JSON files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No project</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No translation files found in this folder</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open</source>
            <translation>打开</translation>
        </message>
        <message>
            <source>Open a project folder to begin</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open project folder</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Open...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>PO files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Progress</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Project</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Properties</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Refresh</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Refresh project files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select Project Folder</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Show in File Manager</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>TS files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translated</source>
            <translation>已翻译</translation>
        </message>
        <message>
            <source>Type</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>XLIFF files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%1 files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>0 files</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Path: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Type: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Size: %s bytes</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total entries: %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translated: %d</source>
            <translation>已翻译：%d</translation>
        </message>
        <message>
            <source>Fuzzy: %d</source>
            <translation>模糊：%d</translation>
        </message>
        <message>
            <source>Untranslated: %d</source>
            <translation>未翻译：%d</translation>
        </message>
        <message>
            <source>Progress: %.1f%%</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Modified: %s</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>QuickActionsMenu</name>
        <message>
            <source>Quick Actions</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>📋 Copy source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>📚 Apply glossary term</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>🔤 Capitalize first letter</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>🔤 Lowercase first letter</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>🧠 Apply TM suggestion</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>RecordMacroDialog</name>
        <message>
            <source>Recording Macro</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Stop Recording</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>🔴 Recording macro...</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>RegexTesterDialog</name>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copied</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copy Result</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Could not copy to clipboard.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Format Strings Found</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Input Text</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Live Preview</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Regex Tester</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Result copied to clipboard.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Sample text</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Test Values</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Test value</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Value</source>
            <translation>值</translation>
        </message>
        <message>
            <source>Error: %s</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>SearchReplaceDialog</name>
        <message>
            <source>%d of %d matches</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Both</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Case sensitive</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter replacement text...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter search text...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find &amp; Replace</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find All</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find Next</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find Previous</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No matches found</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Options</source>
            <translation>选项</translation>
        </message>
        <message>
            <source>Regular expression</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Replace</source>
            <translation>替换</translation>
        </message>
        <message>
            <source>Replace All</source>
            <translation>全部替换</translation>
        </message>
        <message>
            <source>Replace:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search in:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source text</source>
            <translation>源文本</translation>
        </message>
        <message>
            <source>Translation</source>
            <translation>翻译</translation>
        </message>
        <message>
            <source>Whole words</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>SplitDialog</name>
        <message>
            <source>Place the cursor inside the source text to mark the split point.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Segment 1: \u201c{}\u201d  |  Segment 2: \u201c{}\u201d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Split Entry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Click in the source text where you want to split, then press OK.</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>StatisticsDialog</name>
        <message>
            <source>(text contracted)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>(text expanded)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Additional Details</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Average source length</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Average translation length</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Average words per entry</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Characters:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Entry #</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Expansion ratio:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Fuzzy/Needs work:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Length</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Longest Source Strings</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>N/A</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No additional details available.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Overview</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source text:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Text Preview</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Text Statistics</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total entries:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translated:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Progress:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Statistics</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation completion</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Untranslated:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Words:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>characters</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>translated</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>StatsWidget</name>
        <message>
            <source>Auto Translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Best Streak</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Current Streak</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Details</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File Formats</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Files Completed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Formats: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Languages Used</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Languages: {}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Manual Translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total Translations</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation Statistics</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>SyncDialog</name>
        <message>
            <source>%1 resources found</source>
            <translation>找到 %1 个资源</translation>
        </message>
        <message>
            <source>Crowdin not configured. Open Platform Settings first.</source>
            <translation>Crowdin 未配置。请先打开平台设置。</translation>
        </message>
        <message>
            <source>Downloading…</source>
            <translation>正在下载…</translation>
        </message>
        <message>
            <source>Enter a language code</source>
            <translation>请输入语言代码</translation>
        </message>
        <message>
            <source>Language:</source>
            <translation>语言：</translation>
        </message>
        <message>
            <source>Loading resources…</source>
            <translation>正在加载资源…</translation>
        </message>
        <message>
            <source>No file loaded to push</source>
            <translation>没有加载要推送的文件</translation>
        </message>
        <message>
            <source>No resources found</source>
            <translation>未找到资源</translation>
        </message>
        <message>
            <source>Pull</source>
            <translation>拉取</translation>
        </message>
        <message>
            <source>Pull Translation</source>
            <translation>拉取翻译</translation>
        </message>
        <message>
            <source>Push</source>
            <translation>推送</translation>
        </message>
        <message>
            <source>Push Translation</source>
            <translation>推送翻译</translation>
        </message>
        <message>
            <source>Resources</source>
            <translation>资源</translation>
        </message>
        <message>
            <source>Select a resource first</source>
            <translation>请先选择一个资源</translation>
        </message>
        <message>
            <source>Transifex not configured. Open Platform Settings first.</source>
            <translation>Transifex 未配置。请先打开平台设置。</translation>
        </message>
        <message>
            <source>Unknown</source>
            <translation>未知</translation>
        </message>
        <message>
            <source>Unknown platform</source>
            <translation>未知平台</translation>
        </message>
        <message>
            <source>Uploading…</source>
            <translation>正在上传…</translation>
        </message>
        <message>
            <source>Weblate not configured. Open Platform Settings first.</source>
            <translation>Weblate 未配置。请先打开平台设置。</translation>
        </message>
        <message>
            <source>e.g. sv, de, fr</source>
            <translation>例如 sv、de、fr</translation>
        </message>
        <message>
            <source>✓ Downloaded at %1\nSaved to: %2</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>✓ Uploaded at %1</source>
            <translation>✓ 在 %1 上传</translation>
        </message>
        <message>
            <source>✗ Error: %1</source>
            <translation>✗ 错误：%1</translation>
        </message>
        <message>
            <source>✗ Pull failed: %1</source>
            <translation>✗ 拉取失败：%1</translation>
        </message>
        <message>
            <source>✗ Push failed: %1</source>
            <translation>✗ 推送失败：%1</translation>
        </message>
    </context>
    <context>
        <name>ToolbarCustomizeDialog</name>
        <message>
            <source>Check actions to show in toolbar:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Customize Toolbar</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>UnicodeDialog</name>
        <message>
            <source> | ⚠️ Check highlighted characters</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Analyze</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Block</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Category</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Char</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Character Analysis</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Character Details</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Clear</source>
            <translation>清除</translation>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Code Point</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Copy Analysis</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter or paste text to analyze...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Enter text to analyze Unicode characters</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Highlight suspicious characters</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Name</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pos</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Text to Analyze</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Unicode Inspector</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total: {0} characters | Invisible: {1} | Suspicious: {2}</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>ValidationDialog</name>
        <message>
            <source>#</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Errors</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Errors: %d | Warnings: %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Info</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Message</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Quality score: %s%%</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Re-validate</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Severity</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Source text</source>
            <translation>源文本</translation>
        </message>
        <message>
            <source>Validation Results</source>
            <translation>验证结果</translation>
        </message>
        <message>
            <source>Warnings</source>
            <translation>警告</translation>
        </message>
    </context>
    <context>
        <name>VideoDockWidget</name>
        <message>
            <source>Video Preview</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>VideoPreviewWidget</name>
        <message>
            <source>Back 1s (Shift+←)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Forward 1s (Shift+→)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Go to current subtitle (G)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Larger subtitles</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Loop segment (L)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Mute (M)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Next entry (Ctrl+→)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pause</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Pause at segment end</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Play / Pause (Space)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Playback speed</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Previous entry (Ctrl+←)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Smaller subtitles</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Stop (S)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Volume</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>VideoSubtitleDialog</name>
        <message>
            <source>%d subtitle tracks found. Duration: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Cancel</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Browse…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extract and Save As…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extract and Open</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extract Subtitles from Video</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extracting</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extracting preview…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extracting subtitles…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Extraction Error</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Format:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Preview</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Preview failed: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No subtitle tracks found</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No file selected</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Done</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Could not extract the subtitle:\n%s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Could not read the video file:\n%s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Save Subtitle As</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Play / Pause</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Stop</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Close</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>The subtitle has been saved to:\n%s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Subtitle Tracks</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Output Format</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Video File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Video files (%s);;All files (*)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select a video file to preview subtitles</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Select Video File</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>This video file contains no embedded subtitle tracks.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>SRT (.srt)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>WebVTT (.vtt)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>ASS/SSA (.ass)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>SubRip (*.srt)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>WebVTT (*.vtt)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Advanced SubStation Alpha (*.ass)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Subtitle files (*.*)</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>WelcomeDialog</name>
        <message>
            <source>Appearance</source>
            <translation>外观</translation>
        </message>
        <message>
            <source>Back</source>
            <translation>返回</translation>
        </message>
        <message>
            <source>Dark</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Default</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Default engine:</source>
            <translation>默认引擎：</translation>
        </message>
        <message>
            <source>Editor font size:</source>
            <translation>编辑器字体大小：</translation>
        </message>
        <message>
            <source>Email:</source>
            <translation>电子邮件：</translation>
        </message>
        <message>
            <source>Formal</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Formality level:</source>
            <translation>正式程度：</translation>
        </message>
        <message>
            <source>Informal</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Language / Locale:</source>
            <translation>语言 / 区域设置：</translation>
        </message>
        <message>
            <source>Light</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Name:</source>
            <translation>姓名：</translation>
        </message>
        <message>
            <source>Next</source>
            <translation>下一步</translation>
        </message>
        <message>
            <source>Personal Information</source>
            <translation>个人信息</translation>
        </message>
        <message>
            <source>Source language:</source>
            <translation>源语言：</translation>
        </message>
        <message>
            <source>Start translating!</source>
            <translation>开始翻译！</translation>
        </message>
        <message>
            <source>System default</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Target language:</source>
            <translation>目标语言：</translation>
        </message>
        <message>
            <source>Team (optional):</source>
            <translation>团队（可选）：</translation>
        </message>
        <message>
            <source>Theme:</source>
            <translation>主题：</translation>
        </message>
        <message>
            <source>Translation Settings</source>
            <translation>翻译设置</translation>
        </message>
        <message>
            <source>Welcome to LinguaEdit</source>
            <translation>欢迎使用 LinguaEdit</translation>
        </message>
        <message>
            <source>You</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>LinguaEdit is a modern translation editor for PO, TS, JSON, XLIFF,\nAndroid XML, ARB, PHP, and YAML files.\n\nFeatures include AI-powered pre-translation, translation memory,\nquality assurance, spell checking, and platform integration.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>You&apos;re all set!</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Version %s</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>WorldMapWidget</name>
        <message>
            <source>Translation Progress</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>ZenModeWidget</name>
        <message>
            <source>&lt;b&gt;Source text&lt;/b&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Translation&lt;/b&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Exit Zen</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Next entry</source>
            <translation>下一条</translation>
        </message>
        <message>
            <source>Next untranslated ▶▶</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Previous entry</source>
            <translation>上一条</translation>
        </message>
        <message>
            <source>Skip to next untranslated (Ctrl+Enter)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&amp;Catalog</source>
            <translation>目录(&amp;C)</translation>
        </message>
        <message>
            <source>&amp;Edit</source>
            <translation>编辑(&amp;E)</translation>
        </message>
        <message>
            <source>&amp;File</source>
            <translation>文件(&amp;F)</translation>
        </message>
        <message>
            <source>&amp;Git</source>
            <translation>&amp;Git</translation>
        </message>
        <message>
            <source>&amp;Go</source>
            <translation>转到(&amp;G)</translation>
        </message>
        <message>
            <source>&amp;Help</source>
            <translation>帮助(&amp;H)</translation>
        </message>
        <message>
            <source>&amp;Open…</source>
            <translation>打开(&amp;O)…</translation>
        </message>
        <message>
            <source>&amp;Platforms</source>
            <translation>平台(&amp;P)</translation>
        </message>
        <message>
            <source>&amp;Save</source>
            <translation>保存(&amp;S)</translation>
        </message>
        <message>
            <source>&amp;Tools</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&amp;View</source>
            <translation>视图(&amp;V)</translation>
        </message>
        <message>
            <source>&lt;b&gt;%d&lt;/b&gt; untranslated strings out of &lt;b&gt;%d&lt;/b&gt; total.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Added strings:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Changed source text:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Changed translations:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Concordance search&lt;/b&gt;</source>
            <translation>&lt;b&gt;语料搜索&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Outdated translations&lt;/b&gt; — source changed but translation stayed the same.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Potentially outdated:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Reference source:&lt;/b&gt;</source>
            <translation>&lt;b&gt;参考源文本：&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Reference translation:&lt;/b&gt;</source>
            <translation>&lt;b&gt;参考翻译：&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Removed strings:&lt;/b&gt; %d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Source text:&lt;/b&gt;</source>
            <translation>&lt;b&gt;源文本：&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Source text&lt;/b&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Suggestions&lt;/b&gt;</source>
            <translation>&lt;b&gt;建议&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Translation:&lt;/b&gt;</source>
            <translation>&lt;b&gt;翻译：&lt;/b&gt;</translation>
        </message>
        <message>
            <source>&lt;b&gt;Translation&lt;/b&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;b&gt;Translator comment:&lt;/b&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;h3&gt;Comparison Results&lt;/h3&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;(no match in reference)&lt;/i&gt;</source>
            <translation>&lt;i&gt;（参考中无匹配）&lt;/i&gt;</translation>
        </message>
        <message>
            <source>&lt;i&gt;MT unavailable&lt;/i&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;No matches&lt;/i&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;No matching terms&lt;/i&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;No suggestion&lt;/i&gt;</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>&lt;i&gt;No suggestions&lt;/i&gt;</source>
            <translation>&lt;i&gt;无建议&lt;/i&gt;</translation>
        </message>
        <message>
            <source>Are you sure you want to delete the macro &apos;{}&apos;?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Cannot compile: install &apos;polib&apos; or &apos;gettext&apos; (msgfmt)</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Click in the source text where you want to split, then press OK.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Delete term &apos;%s&apos; → &apos;%s&apos;?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>This video file contains no embedded subtitle tracks.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Failed to play macro &apos;{}&apos;.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find &amp; Replace</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Find &amp;&amp; Replace…</source>
            <translation>查找和替换…</translation>
        </message>
        <message>
            <source>Macro &apos;{}&apos; has been saved successfully.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Recording macro &apos;{}&apos;...</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Save &amp;As…</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search &amp; Filter</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Search &amp; Replace</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>The file &apos;%s&apos; has unsaved changes.\nDo you want to save before closing?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Total: {0} characters | Invisible: {1} | Suspicious: {2}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>You&apos;re all set!</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Your credentials are securely stored in the system keychain.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Are you sure you want to rollback to this version?\n\nThis will replace the current text with:\n{}</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OCR functionality requires tesseract-ocr to be installed.\n\nInstall with:\n• macOS: brew install tesseract\n• Ubuntu: sudo apt install tesseract-ocr\n• Windows: download from GitHub</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>%d of %d entries (%d%%) have no translation.\n\nUntranslated entries will be marked and saved with the source text as fallback, so they will still display during playback. When reopened in LinguaEdit, they will be correctly shown as untranslated.\n\nSave anyway?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>A translation file is currently open with unsaved changes.\nSave before loading new subtitles?</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Crowdin Over-The-Air functionality not yet implemented.\nThis would pull latest translations from Crowdin.</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>AIReviewWorker</name>
        <message>
            <source>Translation is missing</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation much longer than source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Translation much shorter than source</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Different number of format markers/tags</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Identical to source text</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>All uppercase when source is not</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>No obvious problems found with this translation.</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Problems identified: </source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>BatchOperationThread</name>
        <message>
            <source>Error: %s</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>FileAnalysisThread</name>
        <message>
            <source>Analyzing %s...</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>GlossaryImportThread</name>
        <message>
            <source>Importing term %d/%d</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Row %d: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>File error: %s</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>TextRenderWidget</name>
        <message>
            <source>Width: %dpx</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>OVERFLOW: +%dpx</source>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>UpdateDialog</name>
        <message>
            <source>Update Available</source>
            <translation>有可用更新</translation>
        </message>
        <message>
            <source>A new version of LinguaEdit is available!</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Current version: %s
New version: %s</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Release notes:</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Skip this version</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Download</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <source>Remind me later</source>
            <translation type="unfinished"/>
        </message>
    </context>
</TS>
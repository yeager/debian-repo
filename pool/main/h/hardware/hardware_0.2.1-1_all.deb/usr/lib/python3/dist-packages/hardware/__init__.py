"""Hardware inventory for GNOME."""

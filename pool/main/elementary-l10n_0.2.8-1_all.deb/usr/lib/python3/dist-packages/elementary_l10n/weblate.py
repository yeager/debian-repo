"""Weblate API client for l10n.elementaryos.org."""

import json
import os
import threading
import time
from pathlib import Path
from typing import Callable

import requests

try:
    import gi
    gi.require_version('Secret', '1')
    from gi.repository import Secret
    HAS_LIBSECRET = True
except (ImportError, ValueError):
    HAS_LIBSECRET = False

BASE_URL = "https://l10n.elementaryos.org"
API = f"{BASE_URL}/api"

CONFIG_DIR = Path.home() / ".config" / "elementary-l10n"
CONFIG_FILE = CONFIG_DIR / "config.json"
CACHE_DIR = Path.home() / ".cache" / "elementary-l10n"
CACHE_FILE = CACHE_DIR / "cache.json"

REQUEST_DELAY = 0.6  # seconds between API calls

# libsecret schema for storing the API key securely
if HAS_LIBSECRET:
    _SECRET_SCHEMA = Secret.Schema.new(
        "se.danielnylander.elementary-l10n",
        Secret.SchemaFlags.NONE,
        {"application": Secret.SchemaAttributeType.STRING},
    )


def _get_api_key_from_keyring() -> str | None:
    """Retrieve API key from GNOME Keyring via libsecret."""
    if not HAS_LIBSECRET:
        return None
    try:
        return Secret.password_lookup_sync(
            _SECRET_SCHEMA, {"application": "elementary-l10n"}, None
        )
    except Exception:
        return None


def _store_api_key_in_keyring(api_key: str) -> bool:
    """Store API key in GNOME Keyring via libsecret."""
    if not HAS_LIBSECRET:
        return False
    try:
        Secret.password_store_sync(
            _SECRET_SCHEMA,
            {"application": "elementary-l10n"},
            Secret.COLLECTION_DEFAULT,
            "elementary-l10n Weblate API Key",
            api_key,
            None,
        )
        return True
    except Exception:
        return False


def _clear_api_key_from_keyring() -> bool:
    """Remove API key from GNOME Keyring."""
    if not HAS_LIBSECRET:
        return False
    try:
        Secret.password_clear_sync(
            _SECRET_SCHEMA, {"application": "elementary-l10n"}, None
        )
        return True
    except Exception:
        return False


def load_config() -> dict:
    """Load config. API key from keyring first, then config file as fallback."""
    try:
        config = json.loads(CONFIG_FILE.read_text())
    except Exception:
        config = {}

    # Try keyring first for API key
    keyring_key = _get_api_key_from_keyring()
    if keyring_key:
        config["api_key"] = keyring_key
    elif config.get("api_key"):
        # Migrate plaintext key to keyring
        if _store_api_key_in_keyring(config["api_key"]):
            # Remove from plaintext config
            migrated_config = {k: v for k, v in config.items() if k != "api_key"}
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            CONFIG_FILE.write_text(json.dumps(migrated_config, indent=2))

    return config


def save_config(config: dict):
    """Save config. API key goes to keyring, rest to config file."""
    api_key = config.pop("api_key", None)

    if api_key:
        if not _store_api_key_in_keyring(api_key):
            # Fallback: save in config file if keyring unavailable
            config["api_key"] = api_key

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))

    # Restore key in dict so callers still have it
    if api_key:
        config["api_key"] = api_key


def load_cache(language_code: str) -> tuple[list | None, float | None]:
    """Load cached data. Returns (data, timestamp) or (None, None)."""
    try:
        cache = json.loads(CACHE_FILE.read_text())
        if cache.get("language") == language_code:
            return cache["data"], cache["timestamp"]
    except Exception:
        pass
    return None, None


def save_cache(language_code: str, data: list):
    """Save data to cache with current timestamp."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps({
        "language": language_code,
        "data": data,
        "timestamp": time.time(),
    }, indent=2))


def _request_with_retry(session: requests.Session, url: str, max_retries: int = 3) -> requests.Response:
    """Make a GET request with exponential backoff on 429."""
    for attempt in range(max_retries + 1):
        r = session.get(url, timeout=15)
        if r.status_code == 401:
            raise RuntimeError(
                "Authentication failed (401). Your API key may be invalid or expired.\n"
                "Go to Settings and enter a valid API key from:\n"
                "https://l10n.elementaryos.org/accounts/profile/#api"
            )
        if r.status_code == 429:
            if attempt >= max_retries:
                # Parse retry-after if available
                retry_after = r.headers.get("Retry-After", "")
                try:
                    wait_info = json.loads(r.text)
                    detail = wait_info.get("errors", [{}])[0].get("detail", "")
                except Exception:
                    detail = ""
                raise RuntimeError(
                    f"Rate limited by Weblate (429). {detail}\n"
                    f"The server is throttling requests. Try again later."
                )
            wait = 2 ** (attempt + 1)
            time.sleep(wait)
            continue
        r.raise_for_status()
        return r
    # Should not reach here, but just in case
    r.raise_for_status()
    return r


def _get_all(url: str, session: requests.Session) -> list:
    """Paginate through Weblate API results with rate limiting."""
    results = []
    while url:
        r = _request_with_retry(session, url)
        data = r.json()
        results.extend(data.get("results", []))
        url = data.get("next")
        if url:
            time.sleep(REQUEST_DELAY)
    return results


def _make_session(api_key: str | None = None) -> requests.Session:
    """Create a requests session with optional API key auth."""
    session = requests.Session()
    session.headers["User-Agent"] = "elementary-l10n/0.1.0"
    if api_key:
        session.headers["Authorization"] = f"Token {api_key}"
    return session


def fetch_projects(session: requests.Session) -> list[dict]:
    return _get_all(f"{API}/projects/", session)


def fetch_components(project_slug: str, session: requests.Session) -> list[dict]:
    return _get_all(f"{API}/projects/{project_slug}/components/", session)


def fetch_statistics(project_slug: str, component_slug: str,
                     language_code: str, session: requests.Session) -> dict:
    url = f"{API}/translations/{project_slug}/{component_slug}/{language_code}/statistics/"
    r = _request_with_retry(session, url)
    return r.json()


def fetch_component_statistics(project_slug: str, component_slug: str,
                               session: requests.Session) -> list[dict]:
    return _get_all(
        f"{API}/components/{project_slug}/{component_slug}/statistics/", session
    )


def component_web_url(project_slug: str, component_slug: str) -> str:
    return f"{BASE_URL}/projects/{project_slug}/{component_slug}/"


def component_translate_url(project_slug: str, component_slug: str,
                            language_code: str) -> str:
    return f"{BASE_URL}/projects/{project_slug}/{component_slug}/{language_code}/"


def fetch_all_data(language_code: str, callback: Callable, error_cb: Callable,
                   cache_cb: Callable | None = None):
    """Fetch all projects, components and stats in a background thread.

    callback(data) on fresh data.
    error_cb(exception) on failure.
    cache_cb(data, age_minutes) if cached data is available (<1h old).
    """
    # Check cache first
    cached_data, cached_ts = load_cache(language_code)
    if cached_data and cached_ts:
        age_seconds = time.time() - cached_ts
        if age_seconds < 3600:  # < 1 hour
            age_minutes = int(age_seconds / 60)
            if cache_cb:
                cache_cb(cached_data, age_minutes)

    def _worker():
        try:
            config = load_config()
            api_key = config.get("api_key")
            session = _make_session(api_key)

            # Quick connectivity check first
            try:
                r = session.get(f"{API}/projects/", timeout=10)
                if r.status_code == 429:
                    try:
                        detail = r.json().get("errors", [{}])[0].get("detail", "")
                    except Exception:
                        detail = ""
                    raise RuntimeError(
                        f"Weblate is rate limiting requests. {detail}\n"
                        "Try again later or check your API key in Settings."
                    )
                if r.status_code == 401:
                    raise RuntimeError(
                        "API key is invalid or expired (401).\n"
                        "Update your key in Settings:\n"
                        "https://l10n.elementaryos.org/accounts/profile/#api"
                    )
            except requests.ConnectionError:
                raise RuntimeError("Could not connect to l10n.elementaryos.org. Check your network.")
            except requests.Timeout:
                raise RuntimeError("Connection to Weblate timed out. Try again later.")

            projects = fetch_projects(session)
            rows = []

            for proj in projects:
                ps = proj["slug"]
                time.sleep(REQUEST_DELAY)
                components = fetch_components(ps, session)

                for comp in components:
                    cs = comp["slug"]
                    time.sleep(REQUEST_DELAY)
                    try:
                        stats = fetch_statistics(ps, cs, language_code, session)
                        pct = stats.get("translated_percent", 0.0)
                    except requests.HTTPError:
                        pct = 0.0

                    rows.append({
                        "project": proj["name"],
                        "project_slug": ps,
                        "component": comp["name"],
                        "component_slug": cs,
                        "translated_percent": pct,
                        "url": component_web_url(ps, cs),
                        "translate_url": component_translate_url(ps, cs, language_code),
                    })

            save_cache(language_code, rows)
            callback(rows)
        except Exception as e:
            error_cb(e)

    t = threading.Thread(target=_worker, daemon=True)
    t.start()

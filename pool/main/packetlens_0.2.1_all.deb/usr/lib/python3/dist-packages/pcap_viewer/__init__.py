"""PacketLens - Network capture analyzer for Linux."""

__version__ = "0.2.1"
__app_id__ = "se.danielnylander.packetlens"

#!/usr/bin/env python3
"""Fedora Translation Status — Main application."""

import gettext
import locale
import sys
import threading
import webbrowser

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib, Gio, Pango  # noqa: E402

from fedora_l10n import __version__, __app_id__
from fedora_l10n.api import (
    get_projects, get_language_statistics, get_components,
    get_component_statistics, clear_cache,
)

# Gettext setup
gettext.bindtextdomain("fedora-l10n", "/usr/share/locale")
gettext.textdomain("fedora-l10n")
_ = gettext.gettext


def _detect_language() -> str:
    """Detect system language, return 2-letter code."""
    try:
        loc = locale.getdefaultlocale()[0]
        if loc:
            return loc.split("_")[0]
    except Exception:
        pass
    return "en"


def _color_for_percent(pct: float) -> str:
    """Return CSS color for translation percentage."""
    if pct >= 100:
        return "#26a269"
    elif pct >= 80:
        return "#2ec27e"
    elif pct >= 50:
        return "#e5a50a"
    elif pct >= 20:
        return "#ff7800"
    else:
        return "#c01c28"


class ProjectRow(Gtk.ListBoxRow):
    """A row showing a project with its translation percentage."""

    def __init__(self, project_data: dict, translated_pct: float):
        super().__init__()
        self.project_data = project_data
        self.slug = project_data.get("slug", "")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.set_margin_top(8)
        box.set_margin_bottom(8)
        box.set_margin_start(12)
        box.set_margin_end(12)

        # Project name
        name_label = Gtk.Label(label=project_data.get("name", self.slug))
        name_label.set_halign(Gtk.Align.START)
        name_label.set_hexpand(True)
        name_label.set_ellipsize(Pango.EllipsizeMode.END)
        box.append(name_label)

        # Percentage bar
        bar = Gtk.LevelBar()
        bar.set_min_value(0)
        bar.set_max_value(100)
        bar.set_value(min(translated_pct, 100))
        bar.set_size_request(120, -1)
        bar.set_valign(Gtk.Align.CENTER)
        box.append(bar)

        # Percentage label
        pct_label = Gtk.Label(label=f"{translated_pct:.0f}%")
        pct_label.set_width_chars(5)
        color = _color_for_percent(translated_pct)
        pct_label.set_markup(f'<span color="{color}" weight="bold">{translated_pct:.0f}%</span>')
        box.append(pct_label)

        self.set_child(box)


class ComponentRow(Gtk.ListBoxRow):
    """A row showing a component with its translation percentage."""

    def __init__(self, name: str, slug: str, translated_pct: float, project_slug: str):
        super().__init__()
        self.component_slug = slug
        self.project_slug = project_slug

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.set_margin_top(6)
        box.set_margin_bottom(6)
        box.set_margin_start(12)
        box.set_margin_end(12)

        name_label = Gtk.Label(label=name)
        name_label.set_halign(Gtk.Align.START)
        name_label.set_hexpand(True)
        name_label.set_ellipsize(Pango.EllipsizeMode.END)
        box.append(name_label)

        bar = Gtk.LevelBar()
        bar.set_min_value(0)
        bar.set_max_value(100)
        bar.set_value(min(translated_pct, 100))
        bar.set_size_request(120, -1)
        bar.set_valign(Gtk.Align.CENTER)
        box.append(bar)

        pct_label = Gtk.Label()
        pct_label.set_width_chars(5)
        color = _color_for_percent(translated_pct)
        pct_label.set_markup(f'<span color="{color}" weight="bold">{translated_pct:.0f}%</span>')
        box.append(pct_label)

        # Link button
        url = f"https://translate.fedoraproject.org/projects/{project_slug}/{slug}/"
        link_btn = Gtk.Button(icon_name="web-browser-symbolic")
        link_btn.set_tooltip_text(_("Open in Weblate"))
        link_btn.add_css_class("flat")
        link_btn.connect("clicked", lambda b: webbrowser.open(url))
        box.append(link_btn)

        self.set_child(box)


class FedoraL10nWindow(Adw.ApplicationWindow):
    """Main application window."""

    def __init__(self, app):
        super().__init__(application=app)
        self.set_title(_("Fedora Translation Status"))
        self.set_default_size(800, 600)

        self._lang = _detect_language()
        self._projects = []
        self._filter_text = ""

        # Main layout
        self._build_ui()

        # Load data
        self._load_projects()

    def _build_ui(self):
        # Header bar
        header = Adw.HeaderBar()

        # Back button (hidden initially)
        self._back_btn = Gtk.Button(icon_name="go-previous-symbolic")
        self._back_btn.set_tooltip_text(_("Back to projects"))
        self._back_btn.connect("clicked", self._on_back)
        self._back_btn.set_visible(False)
        header.pack_start(self._back_btn)

        # Menu button
        menu_btn = Gtk.MenuButton(icon_name="open-menu-symbolic")
        menu = Gio.Menu()
        menu.append(_("Refresh"), "win.refresh")
        menu.append(_("Clear Cache"), "win.clear-cache")
        menu.append(_("About"), "win.about")
        menu_btn.set_menu_model(menu)
        header.pack_end(menu_btn)

        # Actions
        refresh_action = Gio.SimpleAction.new("refresh", None)
        refresh_action.connect("activate", lambda a, p: self._load_projects())
        self.add_action(refresh_action)

        cache_action = Gio.SimpleAction.new("clear-cache", None)
        cache_action.connect("activate", self._on_clear_cache)
        self.add_action(cache_action)

        about_action = Gio.SimpleAction.new("about", None)
        about_action.connect("activate", self._on_about)
        self.add_action(about_action)

        # Search bar
        self._search_entry = Gtk.SearchEntry()
        self._search_entry.set_placeholder_text(_("Filter projects…"))
        self._search_entry.connect("search-changed", self._on_search_changed)

        # Language entry
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        lang_label = Gtk.Label(label=_("Language:"))
        self._lang_entry = Gtk.Entry()
        self._lang_entry.set_text(self._lang)
        self._lang_entry.set_width_chars(5)
        self._lang_entry.set_max_width_chars(5)
        self._lang_entry.connect("activate", self._on_lang_changed)
        lang_box.append(lang_label)
        lang_box.append(self._lang_entry)

        search_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        search_box.set_margin_start(12)
        search_box.set_margin_end(12)
        search_box.set_margin_top(6)
        search_box.set_margin_bottom(6)
        self._search_entry.set_hexpand(True)
        search_box.append(self._search_entry)
        search_box.append(lang_box)

        # Navigation stack
        self._stack = Gtk.Stack()
        self._stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)

        # Project list page
        project_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)
        self._project_list = Gtk.ListBox()
        self._project_list.set_selection_mode(Gtk.SelectionMode.NONE)
        self._project_list.connect("row-activated", self._on_project_activated)
        self._project_list.add_css_class("boxed-list")
        scrolled.set_child(self._project_list)
        project_page.append(scrolled)
        self._stack.add_named(project_page, "projects")

        # Component list page
        component_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        comp_scrolled = Gtk.ScrolledWindow()
        comp_scrolled.set_vexpand(True)
        self._component_list = Gtk.ListBox()
        self._component_list.set_selection_mode(Gtk.SelectionMode.NONE)
        self._component_list.add_css_class("boxed-list")
        comp_scrolled.set_child(self._component_list)
        component_page.append(comp_scrolled)
        self._stack.add_named(component_page, "components")

        # Spinner for loading
        self._spinner = Gtk.Spinner()
        self._spinner.set_size_request(48, 48)
        self._spinner.set_halign(Gtk.Align.CENTER)
        self._spinner.set_valign(Gtk.Align.CENTER)
        spinner_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        spinner_box.set_valign(Gtk.Align.CENTER)
        spinner_box.set_vexpand(True)
        spinner_box.append(self._spinner)
        self._status_label = Gtk.Label(label=_("Loading projects…"))
        spinner_box.append(self._status_label)
        self._stack.add_named(spinner_box, "loading")

        # Main box
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        main_box.append(header)
        main_box.append(search_box)
        main_box.append(self._stack)

        self.set_content(main_box)

    def _load_projects(self):
        self._stack.set_visible_child_name("loading")
        self._spinner.start()
        self._status_label.set_text(_("Loading projects…"))

        def worker():
            try:
                projects = get_projects(
                    callback=lambda p, t: GLib.idle_add(
                        self._status_label.set_text,
                        _("Loading projects… page {page}/{total}").format(page=p, total=t)
                    )
                )
                # Fetch per-language stats for each project
                enriched = []
                for i, proj in enumerate(projects):
                    slug = proj.get("slug", "")
                    try:
                        stats = get_language_statistics(slug, self._lang)
                        pct = stats.get("translated_percent", 0) if stats else 0
                    except Exception:
                        pct = 0
                    enriched.append((proj, pct))
                    if (i + 1) % 10 == 0:
                        GLib.idle_add(
                            self._status_label.set_text,
                            _("Loading statistics… {n}/{total}").format(n=i + 1, total=len(projects))
                        )
                GLib.idle_add(self._populate_projects, enriched)
            except Exception as e:
                GLib.idle_add(self._show_error, str(e))

        threading.Thread(target=worker, daemon=True).start()

    def _populate_projects(self, enriched):
        self._projects = enriched
        self._spinner.stop()
        self._rebuild_project_list()
        self._stack.set_visible_child_name("projects")

    def _rebuild_project_list(self):
        # Clear
        while True:
            row = self._project_list.get_row_at_index(0)
            if row is None:
                break
            self._project_list.remove(row)

        ft = self._filter_text.lower()
        for proj, pct in sorted(self._projects, key=lambda x: x[1], reverse=True):
            name = proj.get("name", proj.get("slug", ""))
            if ft and ft not in name.lower() and ft not in proj.get("slug", "").lower():
                continue
            self._project_list.append(ProjectRow(proj, pct))

    def _on_search_changed(self, entry):
        self._filter_text = entry.get_text()
        self._rebuild_project_list()

    def _on_lang_changed(self, entry):
        new_lang = entry.get_text().strip()
        if new_lang and new_lang != self._lang:
            self._lang = new_lang
            clear_cache()
            self._load_projects()

    def _on_project_activated(self, listbox, row):
        if not isinstance(row, ProjectRow):
            return
        slug = row.slug
        self._back_btn.set_visible(True)
        self.set_title(row.project_data.get("name", slug))
        self._load_components(slug)

    def _load_components(self, slug):
        self._stack.set_visible_child_name("loading")
        self._spinner.start()
        self._status_label.set_text(_("Loading components…"))

        def worker():
            try:
                components = get_components(slug)
                enriched = []
                for i, comp in enumerate(components):
                    comp_slug = comp.get("slug", "")
                    try:
                        stats = get_component_statistics(slug, comp_slug, self._lang)
                        pct = stats.get("translated_percent", 0) if stats else 0
                    except Exception:
                        pct = 0
                    enriched.append((comp, pct))
                GLib.idle_add(self._populate_components, enriched, slug)
            except Exception as e:
                GLib.idle_add(self._show_error, str(e))

        threading.Thread(target=worker, daemon=True).start()

    def _populate_components(self, enriched, project_slug):
        self._spinner.stop()
        # Clear
        while True:
            row = self._component_list.get_row_at_index(0)
            if row is None:
                break
            self._component_list.remove(row)

        for comp, pct in sorted(enriched, key=lambda x: x[1], reverse=True):
            name = comp.get("name", comp.get("slug", ""))
            slug = comp.get("slug", "")
            self._component_list.append(ComponentRow(name, slug, pct, project_slug))

        self._stack.set_visible_child_name("components")

    def _on_back(self, btn):
        self._back_btn.set_visible(False)
        self.set_title(_("Fedora Translation Status"))
        self._stack.set_visible_child_name("projects")

    def _show_error(self, msg):
        self._spinner.stop()
        self._status_label.set_text(_("Error: {msg}").format(msg=msg))

    def _on_clear_cache(self, action, param):
        clear_cache()
        self._load_projects()

    def _on_about(self, action, param):
        about = Adw.AboutWindow(
            application_name=_("Fedora Translation Status"),
            application_icon="preferences-desktop-locale",
            version=__version__,
            developer_name="Daniel Nylander",
            developers=["Daniel Nylander <daniel@danielnylander.se>"],
            copyright="© 2025 Daniel Nylander",
            license_type=Gtk.License.GPL_3_0,
            website="https://github.com/yeager/fedora-l10n",
            issue_url="https://github.com/yeager/fedora-l10n/issues",
            transient_for=self,
        )
        about.present()


class FedoraL10nApp(Adw.Application):
    """Main application class."""

    def __init__(self):
        super().__init__(application_id=__app_id__)
        self._first_run_done = False

    def do_activate(self):
        win = self.get_active_window()
        if not win:
            win = FedoraL10nWindow(self)
            if not self._first_run_done:
                self._first_run_done = True
                self._show_welcome(win)
        win.present()

    def _show_welcome(self, win):
        config_dir = GLib.get_user_config_dir()
        flag = f"{config_dir}/fedora-l10n/.welcome-done"
        if not GLib.file_test(flag, GLib.FileTest.EXISTS):
            dialog = Adw.MessageDialog(
                transient_for=win,
                heading=_("Welcome to Fedora Translation Status!"),
                body=_(
                    "This app shows the translation progress of Fedora projects "
                    "via the Weblate API.\n\n"
                    "Your system language is auto-detected, but you can change it "
                    "using the language field.\n\n"
                    "Click on a project to see its components."
                ),
            )
            dialog.add_response("ok", _("Get Started"))
            dialog.set_default_response("ok")
            dialog.connect("response", lambda d, r: d.close())
            dialog.present()
            # Mark as done
            import os
            os.makedirs(os.path.dirname(flag), exist_ok=True)
            with open(flag, "w") as f:
                f.write("1")


def main():
    app = FedoraL10nApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    main()

"""Svengelska detector — flag unnecessary anglicisms in Swedish text."""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class Anglicism:
    """A detected anglicism with a suggested Swedish alternative."""
    word: str
    suggestion: str
    context: str  # surrounding text
    position: int  # char offset


# Common anglicisms with Swedish alternatives.
# Based on Språkrådet recommendations and common translation pitfalls.
_ANGLICISMS: dict[str, str] = {
    # Verbs
    "implementera": None,  # OK — established in technical Swedish
    "initiera": None,  # OK — established in technical Swedish
    "adressera": "ta itu med, hantera",
    "facilitera": "underlätta",
    "monitorera": "övervaka",
    "trigga": "utlösa, sätta igång",
    "briffa": "informera, instruera",
    "mejla": "e-posta, skicka e-post",
    "googla": "söka på nätet",
    "cancelera": "avboka, ställa in",
    "cancella": "avboka, ställa in",
    "benchmarka": "jämföra, mäta",
    "brainstorma": "idésamla",
    "busta": "spränga, bryta",
    "chilla": "koppla av, ta det lugnt",
    "churna": "tappa kunder",
    "converta": "omvandla, konvertera",
    "delivera": "leverera",
    "dippa": "doppa, sjunka",
    "escalera": "eskalera, trappa upp",
    "fetcha": "hämta",
    "flusha": "spola, tömma",
    "forwarda": "vidarebefordra",
    "launcha": "lansera",
    "lägga upp en story": "publicera",
    "merga": "sammanfoga, slå ihop",
    "pitcha": "presentera, sälja in",
    "pusha": "driva på, trycka på",
    "rendera": None,  # OK — accepted Swedish (confirmed by translator)
    "reseta": "återställa",
    "reviewera": "granska",
    "scrolla": "bläddra, rulla",
    "toggla": "växla",
    "skipa": "hoppa över",
    "sparka av": "starta, dra igång",
    "streama": "strömma, sända",
    "swipa": "svepa",
    "tagga": "märka, märka upp",  # context-dependent: OK in git/tech, bad in general
    "trenda": "vara populär",
    "uppdatera": None,  # OK — established Swedish
    "uppgradera": None,  # OK — established

    # Technical terms — OK in programming/compiler/system context
    "kompilera": None,  # OK — established
    "debugga": None,  # OK — established in tech
    "logga": None,  # OK — established
    "formatera": None,  # OK — established
    "allokera": None,  # OK — established in tech
    "parsea": "tolka, analysera",
    "deploya": "driftsätta",
    "committa": "checka in, versionshantera",
    "brancha": "förgrena",
    "mergea": "sammanfoga, slå ihop",
    "patcha": "laga, programfixa",
    "repostera": "skicka om, vidareskicka",
    "reposta": "skicka om, vidareskicka",

    # Nouns
    "approach": "tillvägagångssätt, metod",
    "awareness": "medvetenhet, kännedom",
    "backup": "säkerhetskopia",
    "benchmark": "riktmärke, jämförelse",
    "best practice": "bästa praxis, god praxis",
    "blocker": "hinder",
    "brainstorm": "idésamling",
    "brief": "instruktion, uppdrag",
    "budget": None,  # OK — established
    "case": None,  # Too many false positives in technical text (switch case, use case)
    "challenge": "utmaning",
    "deadline": "tidsfrist, slutdatum",
    "feature": "funktion, egenskap",
    "feedback": "återkoppling, respons",
    "flow": None,  # OK in technical context (data flow, control flow)
    "gap": "glapp, lucka",
    "high-level": "övergripande",
    "impact": "påverkan, inverkan",
    "input": None,  # OK in technical context (input/output, user input)
    "insight": "insikt",
    "issue": "fråga, problem",
    "item": "punkt, sak",
    "key takeaway": "viktigaste slutsatsen",
    "leverage": "utnyttja, dra nytta av",
    "mindset": "tankesätt, inställning",
    "outcome": "resultat, utfall",
    "output": None,  # OK in technical context (compiler output, I/O)
    "pain point": "smärtpunkt, problem",
    "performance": "prestanda, resultat",
    "pipeline": None,  # OK in technical context (build pipeline, data pipeline)
    "pitch": "presentation, säljpitch",
    "scope": "omfattning, räckvidd",
    "setup": "uppställning, konfiguration",
    "stakeholder": "intressent",
    "startup": "nystartad, uppstart",
    "target": None,  # Too context-dependent — OK in compiler/build context
    "task": "uppgift",
    "team": None,  # OK — established
    "template": None,  # OK in C++/programming context
    "timeline": "tidslinje, tidsplan",
    "tool": None,  # Often used in compound words (tooltip, toolchain) — too many FP
    "touchpoint": "kontaktpunkt",
    "trade-off": "avvägning",
    "trigger": "utlösare",
    "update": None,  # "uppdatera/uppdatering" already established; "update" in tech context OK
    "workshop": None,  # OK — established

    # Adjectives
    "agil": "smidig, flexibel",
    "aligned": None,  # OK in technical context (memory aligned, aligned to)
    "customized": "anpassad, skräddarsydd",
    "dedicated": "engagerad, tillägnad",
    "hands-on": "praktisk, handgriplig",
    "key": None,  # Too many false positives (keyboard key, encryption key, config key)
    "lean": "resurssnål, slimmad",
    "on track": "på rätt spår, i fas",
    "proaktiv": "förebyggande, framåtblickande",
    "senior": "erfaren, ledande",
    "sustainable": "hållbar",
    "transparent": None,  # OK — established
}

# Filter out None (accepted words)
ANGLICISMS = {k: v for k, v in _ANGLICISMS.items() if v is not None}


class SvengelskaChecker:
    """Detect unnecessary anglicisms in Swedish text.
    
    Usage:
        checker = SvengelskaChecker()
        hits = checker.check("Vi behöver implementera en ny approach")
        # → [Anglicism("approach", "tillvägagångssätt, metod", ...)]
    """

    # Swedish inflection suffixes to strip when matching
    # Order matters: longest first
    _SWEDISH_FALSE_POSITIVES = {
        # Native Swedish forms of "blockera" must not match English "blocker".
        "blockera", "blockerar", "blockeras", "blockerade", "blockerades",
        "blockerat", "blockerats", "blockerad", "blockerande",
        "blockering", "blockeringen", "blockeringar", "blockeringarna",
        # HTML tag nouns must not match the verb "tagga".
        "tagg", "taggen", "taggens", "taggar", "taggars", "taggarna", "taggarnas",
        # Native noun forms of "adress" must not match anglicism "adressera".
        "adress", "adressen", "adresser", "adresserna", "adressers",
    }

    _SUFFIXES = (
        "erade", "erades",       # -era verbs past: implementerade
        "ering",                 # noun from -era verb: implementering
        "erna", "arna", "orna",  # plural definite
        "erar",                  # -era verbs present: implementerar
        "erat",                  # -era verbs supine: implementerat
        "ande",                  # present participle
        "ades",                  # past passive
        "ers", "ens", "ets",    # genitive
        "ade",                   # past tense
        "ar", "er", "or",       # plural
        "en", "et", "an",       # definite
        "at", "ad",             # supine / past participle
        "s",                     # genitive / plural
    )

    def __init__(self, *, extra_terms: dict[str, str] | None = None):
        self._terms = dict(ANGLICISMS)
        if extra_terms:
            self._terms.update(extra_terms)
        # Build regex pattern — sort by length (longest first) for greedy match
        escaped = [re.escape(t) for t in sorted(self._terms, key=len, reverse=True)]
        self._pattern = re.compile(
            r'\b(' + '|'.join(escaped) + r')\b',
            re.IGNORECASE,
        )
        # Also build a set for fast stem lookup
        self._term_set = {t.lower() for t in self._terms}

    def _stem_match(self, word: str) -> str | None:
        """Try to match a word to a known anglicism by stripping suffixes."""
        low = word.lower()
        # Explicit extra_terms take priority over exclusions of native forms.
        if low in self._term_set:
            return low
        if low in self._SWEDISH_FALSE_POSITIVES:
            return None
        for suffix in self._SUFFIXES:
            if low.endswith(suffix) and len(low) > len(suffix) + 2:
                stem = low[:-len(suffix)]
                if stem in self._term_set:
                    return stem
                # Try restoring Swedish verb endings after inflection stripping.
                for ending in ("era", "a"):
                    if (stem + ending) in self._term_set:
                        return stem + ending
        return None

    def check(self, text: str) -> list[Anglicism]:
        """Find anglicisms in text."""
        hits = []
        seen_positions: set[int] = set()
        # Flags are literal program syntax, including words such as backup and
        # feature. Keep them intact while still checking the surrounding prose.
        options = [m.span() for m in re.finditer(r'(?<![\w-])--?[A-Za-z][A-Za-z0-9_-]*', text)]
        def inside_option(start, end):
            return any(a <= start and end <= b for a, b in options)

        # First pass: exact pattern matches
        for m in self._pattern.finditer(text):
            if inside_option(m.start(), m.end()):
                continue
            word = m.group(0)
            key = word.lower()
            suggestion = self._terms.get(key, "")
            if not suggestion:
                suggestion = self._terms.get(word, "")
            if suggestion:
                start = max(0, m.start() - 30)
                end = min(len(text), m.end() + 30)
                context = text[start:end]
                hits.append(Anglicism(
                    word=word, suggestion=suggestion,
                    context=context, position=m.start(),
                ))
                seen_positions.add(m.start())

        # Second pass: check inflected forms (word boundaries)
        for m in re.finditer(r'\b(\w+)\b', text):
            if m.start() in seen_positions or inside_option(m.start(), m.end()):
                continue
            stem = self._stem_match(m.group(0))
            if stem:
                suggestion = self._terms[stem]
                start = max(0, m.start() - 30)
                end = min(len(text), m.end() + 30)
                context = text[start:end]
                hits.append(Anglicism(
                    word=m.group(0), suggestion=suggestion,
                    context=context, position=m.start(),
                ))

        hits.sort(key=lambda h: h.position)
        return hits

    @property
    def term_count(self) -> int:
        return len(self._terms)

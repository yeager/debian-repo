"""LinguaEdit — A Qt6 translation file editor."""

__version__ = "1.8.2"
APP_ID = "se.danielnylander.LinguaEdit"

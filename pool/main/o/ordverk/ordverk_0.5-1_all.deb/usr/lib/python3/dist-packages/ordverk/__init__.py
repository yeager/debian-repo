"""Ordverk — Swedish translation workbench."""

__version__ = "0.5"

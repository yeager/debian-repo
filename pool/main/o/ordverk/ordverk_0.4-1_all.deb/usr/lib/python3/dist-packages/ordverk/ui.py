"""Native GTK4/libadwaita workbench. Worker results are marshalled to the main loop."""
from __future__ import annotations

import copy
import json
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from pathlib import Path

from .gtk_support import Adw, Gdk, Gio, GLib, GObject, Gtk, Pango

from . import __version__
from .ai_context import catalog_context
from .ai_providers import is_configured, provider_for
from .selection import FILTERS, matches
from .catalog import atomic_write
from .dialogs import ImportGuide, Preferences, PretranslateDialog
from .importers import import_sources
from .llm import Translator
from .quality import Quality
from .quality_index import ReviewIndex, signature
from .progress import LatestProgress, ProgressState
from .resources import ResourceStore
from .remote_dialogs import Connections, MailDialog
from .diff_dialog import DiffDialog
from .export_dialog import ExportDialog
from .header_dialog import HeaderDialog
from .po_header import stamp_translator
from .pot_dialog import choose_template
from .diffs import parse_diff, propose_diff
from .settings import Settings
from .statistics import statistics
from .workflow import apply_changes, batch_translate


def label(text="", css=None, wrap=False):
    widget = Gtk.Label(label=text, xalign=0, wrap=wrap, selectable=True)
    if css:
        widget.add_css_class(css)
    return widget


def clear(box):
    while box.get_first_child():
        box.remove(box.get_first_child())


def button(text, callback, icon=None, css=None):
    widget = Gtk.Button(label=text)
    if icon:
        content = Gtk.Box(spacing=6)
        content.append(Gtk.Image.new_from_icon_name(icon))
        content.append(Gtk.Label(label=text))
        widget.set_child(content)
    if css:
        widget.add_css_class(css)
    widget.connect("clicked", lambda _: callback())
    return widget


def scroll(child, **kwargs):
    view = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, **kwargs)
    view.set_child(child)
    return view


class UnitRow(GObject.Object):
    changed = GObject.Signal()

    def __init__(self, unit, number=1):
        super().__init__()
        self.unit = unit
        self.number = number


class Window(Adw.ApplicationWindow):
    def __init__(self, application, *, settings=None, store=None, startup=True):
        super().__init__(application=application, title="Ordverk", default_width=1440, default_height=920)
        self.settings = settings or Settings.load()
        self.store = store or ResourceStore()
        self.session_key = ""
        self.catalogs, self.catalog, self.unit = [], None, None
        self.variant, self.loading, self.closed = 0, False, False
        self.executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="ordverk")
        self.check_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ordverk-check")
        self.review_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ordverk-review")
        self.quality_indexes = {}
        self.statistics_views = []
        self.quality_queue = []
        self.quality_running = None
        self.quality_cancel = threading.Event()
        self.quality_meter = None
        self.quality_progress = LatestProgress()
        self.check_future = None
        self.check_generation = 0
        self.job_cancel, self.resource_cancel = threading.Event(), threading.Event()
        self.busy, self.updating = False, False
        self.job_meter = self.resource_meter = self.check_meter = None
        self.progress_timer = None
        self.pending_progress = LatestProgress()
        self.diagnostics = []
        self.session_statistics = {"memory": 0, "ai": 0}
        self.marked = set()
        self.suggestion_generation = 0
        self.suggestion_meter = None
        self.suggestion_future = None
        self.report_ready = False
        self.connection_tokens = {}
        self.close_dialog = None
        self.refresh_services()
        self._build()
        icon_folder = Path(__file__).resolve().parents[2] / "data"
        if icon_folder.is_dir():
            Gtk.IconTheme.get_for_display(self.get_display()).add_search_path(str(icon_folder))
        Gtk.IconTheme.get_for_display(self.get_display()).add_search_path(str(Path(sys.prefix) / "share/pixmaps"))
        self.set_icon_name("io.github.yeager.Ordverk")
        self.connect("close-request", self.on_close)
        self._actions()
        if startup and self.settings.auto_update_resources:
            GLib.idle_add(self.update_resources)

    def refresh_services(self):
        self.quality = Quality(self.settings, self.store)
        self.translator = Translator(self.settings, self.store, self.quality, self.session_key)
        if hasattr(self, "quality_status") and self.catalogs:
            self.cancel_quality()
            self.quality_indexes.clear()
            if self.settings.auto_review_imports:
                self.queue_quality(self.catalogs)
            self.update_quality_view()
        if hasattr(self, "api_status"):
            service = self.settings.model or provider_for(self.settings).name
            self.api_status.set_label(f"AI · {service}" if is_configured(self.settings) else "AI inte konfigurerad")
            self.schedule_check()

    def _build(self):
        self.toasts = Adw.ToastOverlay()
        self.set_content(self.toasts)
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.toasts.set_child(root)
        header = Adw.HeaderBar()
        self.title_widget = Adw.WindowTitle(title="Ordverk", subtitle="Din svenska översättningsverkstad")
        header.set_title_widget(self.title_widget)
        menu = Gio.Menu()
        for text, action in [("Filer…", "win.open"), ("Mapp med undermappar…", "win.folder"),
                             ("Uppdatera PO från POT…", "win.pot"),
                             ("Diff / patch…", "win.diff"),
                             ("URL eller GitHub-förråd…", "win.url"), ("Översättningsminne (PO)…", "win.memory"),
                             ("Terminologi (TBX / CSV)…", "win.terms"), ("GitHub / Weblate / Transifex / Crowdin…", "win.connections")]:
            menu.append(text, action)
        import_button = Gtk.MenuButton(label="Importera", menu_model=menu, css_classes=["suggested-action"])
        header.pack_start(import_button)
        self.save_button = button("Spara", self.save, "document-save-symbolic")
        self.save_button.set_sensitive(False)
        header.pack_start(self.save_button)
        header.pack_start(button("Exportera…", self.export_files))
        header.pack_start(button("Föröversätt…", self.pretranslate))
        header.pack_end(button("Inställningar", lambda: Preferences(self).present(), "emblem-system-symbolic"))
        more = Gio.Menu()
        for text, action in [("Spara som…", "win.save-as"), ("Koppla käll-JSON…", "win.reference"),
                             ("Kör importguiden igen…", "win.guide"), ("Granska hela filen", "win.review-file"),
                             ("Exportera granskningsrapport…", "win.report"), ("Exportera eget minne…", "win.export-memory"),
                             ("Uppdatera språkresurser", "win.update"), ("Om Ordverk", "win.about")]:
            more.append(text, action)
        more.append("Importera eller exportera till tjänst…", "win.connections")
        more.append("Skicka via e-post / TP…", "win.mail")
        more.append("Avsluta", "win.quit")
        more.append("Redigera PO-huvud…", "win.po-header")
        header.pack_end(Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=more))
        root.append(header)

        toolbar = Gtk.Box(spacing=10, margin_start=16, margin_end=16, margin_top=10, margin_bottom=10)
        self.file_names = Gtk.StringList()
        self.file_picker = Gtk.DropDown(model=self.file_names, hexpand=True, enable_search=True)
        self.file_picker.set_tooltip_text("Importerade kataloger")
        self.file_picker.connect("notify::selected", self.select_catalog)
        toolbar.append(self.file_picker)
        service = self.settings.model or provider_for(self.settings).name
        self.api_status = label(f"AI · {service}" if is_configured(self.settings) else "AI inte konfigurerad", "dim-label")
        toolbar.append(self.api_status)
        toolbar.append(button("Statistik", self.show_statistics, "view-list-symbolic"))
        toolbar.append(button("Granska fil", lambda: self.review_catalogs([self.catalog]) if self.catalog else None,
                              "object-select-symbolic"))
        root.append(toolbar)
        summary = Gtk.Box(spacing=24, margin_start=18, margin_end=18, margin_bottom=12)
        self.statistics_labels = {}
        for key, caption in [("total", "strängar"), ("translated", "översatta"), ("reviewed", "granskade"), ("remaining", "kvar")]:
            box = Gtk.Box(spacing=6)
            value = label("0", "heading")
            self.statistics_labels[key] = value
            box.append(value)
            box.append(label(caption, "dim-label"))
            summary.append(box)
        self.completion = Gtk.ProgressBar(show_text=True, text="0 % översatt", hexpand=True, valign=Gtk.Align.CENTER)
        summary.append(self.completion)
        root.append(summary)
        self.quality_status = label("Importera en fil för att se kvalitetsstatistik.", "dim-label", wrap=True)
        self.quality_status.set_margin_start(18)
        self.quality_status.set_margin_end(18)
        self.quality_status.set_margin_bottom(8)
        root.append(self.quality_status)
        quality_controls = Gtk.Box(spacing=8, margin_start=18, margin_end=18, margin_bottom=8)
        self.quality_bar = Gtk.ProgressBar(show_text=True, hexpand=True, visible=False)
        self.quality_stop = button("Avbryt kvalitetsgranskning", self.cancel_quality)
        self.quality_stop.set_visible(False)
        quality_controls.append(self.quality_bar)
        quality_controls.append(self.quality_stop)
        root.append(quality_controls)
        root.append(Gtk.Separator())
        self.stack = Gtk.Stack(vexpand=True)
        root.append(self.stack)
        welcome = Adw.StatusPage(title="Välkommen till Ordverk", icon_name="io.github.yeager.Ordverk",
                                 description="Översätt med sammanhang. Granska med omsorg.\nPO · Qt TS · XLIFF · JSON")
        welcome_buttons = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, halign=Gtk.Align.CENTER)
        welcome_buttons.append(button("Importera filer", lambda: self.choose_files(), css="suggested-action"))
        welcome_buttons.append(button("Importera en mapp", self.choose_folder))
        welcome_buttons.append(button("Hämta från URL eller GitHub", self.url_dialog))
        welcome_buttons.append(label("Du kan också släppa filer och mappar här.", "dim-label"))
        welcome.set_child(welcome_buttons)
        self.stack.add_named(welcome, "welcome")

        workspace = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, position=335,
                              resize_start_child=False, shrink_start_child=False, shrink_end_child=False)
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, width_request=260,
                       margin_start=12, margin_end=12, margin_top=14, margin_bottom=12)
        left.append(label("STRÄNGAR", "heading"))
        self.search = Gtk.SearchEntry(placeholder_text="Sök källtext, svenska eller kontext")
        self.search.connect("search-changed", lambda _: self.filter_units())
        left.append(self.search)
        self.filter = Gtk.DropDown.new_from_strings([title for _, title in FILTERS])
        self.filter.set_tooltip_text("Kvalitetsfilter visar hittills hittade avvikelser. Granska fil uppdaterar alla strängar. Ändringar sedan import jämförs även efter sparning.")
        self.filter.connect("notify::selected", lambda *_: self.filter_units())
        left.append(self.filter)
        marked_controls = Gtk.Box(spacing=6)
        marked_controls.append(button("Markera visade", lambda: self.mark_visible(True)))
        marked_controls.append(button("Rensa", lambda: self.mark_visible(False)))
        left.append(marked_controls)
        self.unit_store = Gio.ListStore.new(UnitRow)
        self.selection = Gtk.SingleSelection(model=self.unit_store, autoselect=False)
        self.selection.connect("notify::selected-item", self.select_unit)
        factory = Gtk.SignalListItemFactory()
        factory.connect("setup", self.setup_row)
        factory.connect("bind", self.bind_row)
        factory.connect("unbind", self.unbind_row)
        self.unit_list = Gtk.ListView(model=self.selection, factory=factory, css_classes=["navigation-sidebar"])
        left.append(scroll(self.unit_list, vexpand=True))
        self.list_count = label("", "dim-label")
        left.append(self.list_count)
        workspace.set_start_child(left)

        right = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, position=630,
                          resize_start_child=True, resize_end_child=False, shrink_start_child=False, shrink_end_child=False)
        editor = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, width_request=360,
                         margin_start=22, margin_end=22, margin_top=20, margin_bottom=20)
        caption = Gtk.Box(spacing=8)
        caption.append(label("ÖVERSÄTTNING", "heading"))
        self.unit_status = Gtk.Label(hexpand=True, xalign=1, css_classes=["dim-label"])
        caption.append(self.unit_status)
        editor.append(caption)
        self.context_label = label("", "dim-label", wrap=True)
        editor.append(self.context_label)
        self.variants = Gtk.DropDown()
        self.variants.connect("notify::selected", self.select_variant)
        editor.append(self.variants)
        editor.append(label("Källtext", "heading"))
        self.source_view = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.WORD_CHAR,
                                        left_margin=12, right_margin=12, top_margin=12, bottom_margin=12)
        editor.append(scroll(self.source_view, min_content_height=100, max_content_height=200, css_classes=["card"]))
        target_caption = Gtk.Box(spacing=8)
        target_caption.append(label("Svenska", "heading"))
        self.length_label = Gtk.Label(hexpand=True, xalign=1, css_classes=["dim-label"])
        target_caption.append(self.length_label)
        editor.append(target_caption)
        self.target_view = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, accepts_tab=False,
                                        left_margin=12, right_margin=12, top_margin=12, bottom_margin=12)
        self.target_buffer = self.target_view.get_buffer()
        self.target_buffer.set_enable_undo(True)
        self.target_buffer.connect("changed", self.target_changed)
        editor.append(scroll(self.target_view, min_content_height=150, vexpand=True, css_classes=["card"]))
        controls = Gtk.Box(spacing=8)
        self.ai_button = button("Föreslå med AI", self.request_ai, "system-search-symbolic")
        controls.append(self.ai_button)
        controls.append(button("Kopiera källa", self.copy_source))
        self.review_button = button("Markera granskad", self.mark_reviewed, "object-select-symbolic", "suggested-action")
        controls.append(self.review_button)
        editor.append(controls)
        editor.append(button("Visa kontext till AI", self.preview_ai_context))
        self.notes = label("", "dim-label", wrap=True)
        editor.append(self.notes)
        self.issue_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.issue_box.append(label("Välj en sträng för att börja granska.", "dim-label", wrap=True))
        self.check_bar = Gtk.ProgressBar(show_text=True, text="Granskar strängen…", visible=False)
        editor.append(self.check_bar)
        expander = Gtk.Expander(label="Kvalitetskontroller", expanded=True)
        expander.set_child(scroll(self.issue_box, min_content_height=110, max_content_height=190))
        editor.append(expander)
        right.set_start_child(editor)

        help_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18, width_request=310,
                             margin_start=18, margin_end=18, margin_top=20, margin_bottom=20)
        help_panel.append(label("SPRÅKSTÖD", "heading"))
        help_panel.append(label("Förslag med sammanhang", "title-3"))
        help_panel.append(label("Bedöm alltid träffen i sitt nya sammanhang.", "dim-label", wrap=True))
        self.suggestion_bar = Gtk.ProgressBar(show_text=True, visible=False)
        help_panel.append(self.suggestion_bar)
        self.proposal_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=9)
        help_panel.append(self.proposal_box)
        help_panel.append(Gtk.Separator())
        help_panel.append(label("Översättningsminne", "heading"))
        self.memory_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        help_panel.append(self.memory_box)
        help_panel.append(Gtk.Separator())
        help_panel.append(label("Terminologi", "heading"))
        self.term_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        help_panel.append(self.term_box)
        help_panel.append(Gtk.Separator())
        help_panel.append(label("Referenser", "heading"))
        for title, uri in [("Computer Swedens IT-ord", "https://it-ord.computersweden.se/"),
                           ("SAOL · SO · SAOB", "https://svenska.se/"),
                           ("Rikstermbanken", "https://www.rikstermbanken.se/")]:
            help_panel.append(Gtk.LinkButton(uri=uri, label=title, halign=Gtk.Align.START))
        right.set_end_child(scroll(help_panel))
        workspace.set_end_child(right)
        self.stack.add_named(workspace, "workspace")

        root.append(Gtk.Separator())
        footer = Gtk.Box(spacing=12, margin_start=16, margin_end=16, margin_top=9, margin_bottom=9)
        self.progress = Gtk.Spinner()
        footer.append(self.progress)
        self.status = label("Redo att importera", "dim-label")
        self.status.set_ellipsize(Pango.EllipsizeMode.END)
        self.status.set_hexpand(True)
        footer.append(self.status)
        self.cancel_button = button("Avbryt", self.cancel_job)
        self.cancel_button.set_visible(False)
        footer.append(self.cancel_button)
        root.append(footer)
        self.job_bar = Gtk.ProgressBar(show_text=True, visible=False, margin_start=16, margin_end=16, margin_bottom=8)
        root.append(self.job_bar)
        self.resource_status = Gtk.Label(label="Språkresurser · lokalt minne", xalign=0, margin_start=16,
                                         margin_end=16, margin_bottom=8, css_classes=["caption", "dim-label"])
        self.resource_status.set_ellipsize(Pango.EllipsizeMode.END)
        resource_footer = Gtk.Box(spacing=8)
        self.resource_status.set_hexpand(True)
        resource_footer.append(self.resource_status)
        self.resource_stop = button("Avbryt uppdatering", lambda: self.resource_cancel.set())
        self.resource_stop.set_visible(False)
        resource_footer.append(self.resource_stop)
        root.append(resource_footer)
        self.resource_bar = Gtk.ProgressBar(show_text=True, visible=False, margin_start=16, margin_end=16, margin_bottom=8)
        root.append(self.resource_bar)
        drop = Gtk.DropTarget.new(Gdk.FileList, Gdk.DragAction.COPY)
        drop.connect("drop", self.on_drop)
        self.add_controller(drop)
        self.refresh_services()
        counts = self.store.counts()
        self.resource_status.set_label(f"Språkresurser · {counts['memory']:,} minnesposter · {counts['terms']:,} termer".replace(",", " "))

    def _actions(self):
        actions = {
            "open": self.choose_files, "folder": self.choose_folder, "url": self.url_dialog,
            "save": self.save, "save-as": lambda: self.save(True), "reference": self.choose_reference,
            "memory": lambda: self.choose_resource("memory"), "terms": lambda: self.choose_resource("terms"),
            "guide": lambda: ImportGuide(self, [self.catalog]).present() if self.catalog else None,
            "review-file": lambda: self.review_catalogs([self.catalog]) if self.catalog else None,
            "report": self.export_report, "export-memory": self.export_memory,
            "update": self.update_resources, "about": self.about,
            "next": lambda: self.move(1), "previous": lambda: self.move(-1),
            "approve": self.mark_reviewed,
            "pretranslate": self.pretranslate,
            "export": self.export_files,
            "po-header": self.edit_po_header,
            "pot": lambda: choose_template(self),
            "quit": self.close,
            "connections": lambda: Connections(self).present(),
            "diff": self.import_diff,
            "mail": lambda: MailDialog(self).present() if self.catalog else self.toast("Importera en fil först."),
        }
        for name, callback in actions.items():
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", lambda _a, _p, callback=callback: callback())
            self.add_action(action)
        for action, keys in {"open": ["<Control>o"], "save": ["<Control>s"], "save-as": ["<Control><Shift>s"],
                             "next": ["<Alt>Down"], "previous": ["<Alt>Up"], "approve": ["<Control>Return"],
                             "quit": ["<Control>q"]}.items():
            self.get_application().set_accels_for_action("win." + action, keys)

    def toast(self, text):
        if not self.closed:
            self.toasts.add_toast(Adw.Toast(title=text, timeout=5))

    def error(self, text, parent=None):
        if self.closed:
            return
        dialog = Adw.MessageDialog(transient_for=parent or self, modal=True, heading="Det gick inte att slutföra", body=str(text))
        dialog.add_response("ok", "Stäng")
        dialog.present()

    def dispatch(self, callback, *args):
        def run():
            if not self.closed:
                callback(*args)
            return False
        GLib.idle_add(run)

    def job(self, text, operation, done):
        if self.busy:
            self.toast("Låt det pågående arbetet bli klart eller avbryt det först.")
            return
        self.busy = True
        self.pending_progress.take()
        self.job_meter = ProgressState()
        self.start_progress_timer()
        self.job_cancel = threading.Event()
        self.progress.start()
        self.cancel_button.set_visible(True)
        self.status.set_label(text)
        future = self.executor.submit(operation, self.job_cancel)

        def complete(f):
            def finish():
                self.flush_progress()
                self.busy = False
                self.job_meter = None
                self.job_bar.set_visible(False)
                self.stack.set_sensitive(True)
                self.progress.stop()
                self.cancel_button.set_visible(False)
                try:
                    result = f.result()
                    done(result)
                except Exception as exc:
                    self.status.set_label("Arbetet kunde inte slutföras")
                    self.error(str(exc))
            self.dispatch(finish)
        future.add_done_callback(complete)
        return True

    def progress_message(self, text, current=None, total=None):
        self.pending_progress.put(text, current, total)

    def flush_progress(self):
        update = self.pending_progress.take()
        if update:
            text, current, total = update
            self.status.set_label(text)
            if self.job_meter:
                self.job_meter.update(current, total)

    def start_progress_timer(self):
        if self.progress_timer is None:
            self.progress_timer = GLib.timeout_add(120, self.tick_progress)

    def tick_progress(self):
        self.flush_progress()
        update = self.quality_progress.take()
        if update and self.quality_meter:
            text, current, total = update
            self.quality_meter.update(current, total)
            self.quality_bar.set_tooltip_text(text)
        for meter, bar in ((self.job_meter, self.job_bar), (self.resource_meter, self.resource_bar),
                           (self.check_meter, self.check_bar), (self.suggestion_meter, self.suggestion_bar),
                           (self.quality_meter, self.quality_bar)):
            visible = meter is not None and meter.visible()
            bar.set_visible(visible)
            if visible:
                if meter.fraction is None:
                    bar.set_text("Arbetar…")
                    bar.pulse()
                else:
                    bar.set_fraction(meter.fraction)
                    bar.set_text(f"{meter.current} av {meter.total} · {meter.fraction:.0%}")
        self.refresh_statistics_views(progress_only=True)
        self.quality_stop.set_visible(self.quality_meter is not None and self.quality_meter.visible())
        self.resource_stop.set_visible(self.resource_meter is not None and self.resource_meter.visible())
        if self.closed or not any((self.job_meter, self.resource_meter, self.check_meter, self.suggestion_meter, self.quality_meter)):
            self.progress_timer = None
            return False
        return True

    def cancel_job(self):
        self.job_cancel.set()
        self.status.set_label("Avbryter efter pågående anrop…")

    def update_resources(self, components=None):
        if self.updating:
            self.toast("Språkresurserna uppdateras redan.")
            return False
        self.updating = True
        self.resource_cancel = threading.Event()
        self.resource_meter = ProgressState()
        self.start_progress_timer()
        components = list(components if components is not None else self.settings.resource_components)
        def progress(text, current=None, total=None):
            def update():
                self.resource_status.set_label(text)
                if self.resource_meter:
                    self.resource_meter.update(current, total)
            self.dispatch(update)
        future = self.executor.submit(self.store.update, components,
                                       progress=progress,
                                       cancel=self.resource_cancel)

        def done(f):
            def finish():
                self.updating = False
                self.resource_meter = None
                self.resource_bar.set_visible(False)
                self.resource_stop.set_visible(False)
                try:
                    errors = f.result()
                    counts = self.store.counts()
                    summary = f"Språkresurser · {counts['memory']:,} minnesposter · {counts['terms']:,} termer".replace(",", " ")
                    if errors:
                        summary += " · Uppdateringen är ofullständig (se information)"
                        self.resource_status.set_tooltip_text("\n".join(errors))
                        self.toast("Vissa språkresurser kunde inte uppdateras. Tillgänglig cache används.")
                    self.resource_status.set_label(summary)
                    self.refresh_services()
                    self.schedule_check()
                    self.refresh_suggestions()
                except Exception as exc:
                    self.resource_status.set_label("Tillgänglig cache används · " + str(exc))
            self.dispatch(finish)
        future.add_done_callback(done)
        return False

    def file_dialog(self, title, callback, *, patterns=None, folder=False, multiple=False, save_name=None):
        dialog = Gtk.FileDialog(title=title, modal=True, accept_label="Spara" if save_name else "Välj")
        if patterns:
            file_filter = Gtk.FileFilter(name=title)
            for pattern in patterns:
                file_filter.add_pattern(pattern)
            dialog.set_filters(Gio.ListStore.new(Gtk.FileFilter))
            dialog.get_filters().append(file_filter)
        if save_name:
            dialog.set_initial_name(save_name)

        def response(d, result):
            try:
                if folder:
                    selected = d.select_folder_finish(result)
                elif save_name:
                    selected = d.save_finish(result)
                elif multiple:
                    files = d.open_multiple_finish(result)
                    callback([files.get_item(i).get_path() for i in range(files.get_n_items())])
                    return
                else:
                    selected = d.open_finish(result)
                if not selected.get_path():
                    raise ValueError("Välj en lokal fil eller använd URL-import.")
                callback(selected.get_path())
            except GLib.Error:
                return
            except Exception as exc:
                self.error(str(exc))
        if folder:
            dialog.select_folder(self, None, response)
        elif save_name:
            dialog.save(self, None, response)
        elif multiple:
            dialog.open_multiple(self, None, response)
        else:
            dialog.open(self, None, response)

    def choose_files(self):
        self.file_dialog("Importera översättningsfiler", self.import_paths, multiple=True)

    def choose_folder(self):
        self.file_dialog("Importera en mapp", lambda path: self.import_paths([path]), folder=True)

    def import_diff(self):
        if not self.catalogs:
            self.toast("Importera filerna som diffen gäller först.")
            return
        def load(path):
            def run(cancel):
                from .importers import check_cancel
                proposals = []
                for patch in parse_diff(Path(path).read_text(encoding="utf-8-sig")):
                    check_cancel(cancel)
                    matches = [c for c in self.catalogs if str(c.path or c.name).endswith("/" + patch.before) or c.name == patch.before]
                    if not matches:
                        matches = [c for c in self.catalogs if Path(c.name).name == Path(patch.before).name]
                    if len(matches) != 1:
                        raise ValueError(f"{patch.before}: importera en entydig grundfil först. {len(matches)} matchande filer är öppna.")
                    proposals.append(propose_diff(matches[0], patch))
                return proposals
            self.job("Läser och jämför diff…", run, lambda proposals: [DiffDialog(self, p).present() for p in proposals])
        self.file_dialog("Importera unified diff", load, patterns=["*.diff", "*.patch"])

    def url_dialog(self):
        dialog = Adw.MessageDialog(transient_for=self, heading="Importera från nätet",
                                   body="Ange en direktadress till en PO-, TS-, XLIFF- eller JSON-fil, eller ett offentligt GitHub-förråd.")
        entry = Gtk.Entry(placeholder_text="https://…", activates_default=True)
        dialog.set_extra_child(entry)
        dialog.add_response("cancel", "Avbryt")
        dialog.add_response("import", "Importera")
        dialog.set_default_response("import")
        dialog.set_response_appearance("import", Adw.ResponseAppearance.SUGGESTED)
        dialog.connect("response", lambda _d, response: self.import_paths([entry.get_text().strip()]) if response == "import" else None)
        dialog.present()

    def on_drop(self, _target, value, _x, _y):
        self.import_paths([f.get_path() or f.get_uri() for f in value.get_files()])
        return True

    def import_paths(self, paths):
        self.job("Importerar…", lambda cancel: import_sources(paths, progress=self.progress_message, cancel=cancel), self.finish_import)

    def finish_import(self, result):
        new = []
        origins = {c.origin for c in self.catalogs}
        for catalog in result.catalogs:
            if catalog.origin not in origins:
                origins.add(catalog.origin)
                new.append(catalog)
        first = len(self.catalogs)
        self.catalogs.extend(new)
        self.refresh_files()
        if new:
            self.file_picker.set_selected(first)
            self.select_catalog()
            self.stack.set_visible_child_name("workspace")
        self.status.set_label(f"{len(new)} filer importerades" + (" · importen avbröts" if result.cancelled else ""))
        if result.errors:
            self.show_report("Importresultat", result.errors)
        if new and self.settings.auto_review_imports:
            self.queue_quality(new)
        if new:
            self.show_statistics(catalogs=new, title="Importstatistik")
        if new and not result.cancelled:
            if self.settings.show_import_guide or any(c.language and not c.language.lower().startswith("sv") for c in new):
                ImportGuide(self, new).present()
            else:
                self.start_workflow(new, self.settings.import_purpose, self.settings.import_automatic,
                                    self.settings.automatic_use_ai)

    def quality_index(self, catalog):
        return self.quality_indexes.setdefault(catalog, ReviewIndex())

    def quality_groups(self, catalog, unit):
        return self.quality_index(catalog).groups(unit)

    def update_quality_view(self, *, refilter=False):
        if not self.catalog:
            return
        self.quality_status.set_label(self.quality_index(self.catalog).summary(self.catalog))
        self.refresh_statistics_views()
        kind = FILTERS[self.filter.get_selected()][0]
        if refilter and kind.startswith("quality-"):
            query = self.search.get_text().casefold()
            expected = [u for u in self.catalog.units
                        if matches(u, kind, quality_groups=self.quality_groups(self.catalog, u))
                        and (not query or query in "\n".join([u.source, *u.targets, u.context, u.notes]).casefold())]
            if [id(row.unit) for row in self.unit_store] != [id(u) for u in expected]:
                self.filter_units()

    def queue_quality(self, catalogs):
        for catalog in catalogs:
            if (catalog is not self.quality_running or self.quality_cancel.is_set()) and catalog not in self.quality_queue:
                self.quality_queue.append(catalog)
                self.quality_index(catalog).state = "Väntar på kvalitetsgranskning"
        self.start_quality()

    def start_quality(self):
        if self.closed or self.quality_running is not None or not self.quality_queue:
            return
        catalog = self.quality_queue.pop(0)
        self.quality_running = catalog
        self.quality_cancel = threading.Event()
        cancel, quality = self.quality_cancel, self.quality
        index = self.quality_index(catalog)
        index.state = "Kvalitetsgranskning pågår"
        self.quality_progress.take()
        self.quality_meter = ProgressState()
        self.start_progress_timer()
        self.update_quality_view()

        def run():
            snapshot = copy.deepcopy(catalog)
            issues = quality.catalog(snapshot, cancel=cancel, progress=self.quality_progress.put)
            return snapshot, issues

        def done(future):
            def finish():
                self.quality_running = None
                self.quality_meter = None
                self.quality_bar.set_visible(False)
                self.quality_stop.set_visible(False)
                try:
                    snapshot, issues = future.result()
                    if not cancel.is_set() and quality is self.quality:
                        index.apply(catalog, snapshot, issues)
                    else:
                        index.state = "Kvalitetsgranskningen behöver köras igen"
                except Exception as exc:
                    index.state = "Kvalitetsgranskningen avbröts" if cancel.is_set() else f"Kvalitetsgranskningen misslyckades: {exc}"
                self.update_quality_view(refilter=True)
                self.start_quality()
            self.dispatch(finish)
        self.review_executor.submit(run).add_done_callback(done)

    def cancel_quality(self):
        self.quality_cancel.set()
        for catalog in self.quality_queue:
            self.quality_index(catalog).state = "Kvalitetsgranskningen avbröts"
        self.quality_queue.clear()
        if self.quality_running:
            self.quality_index(self.quality_running).state = "Avbryter kvalitetsgranskningen"
        self.update_quality_view()

    def add_copies(self, catalogs):
        first = len(self.catalogs)
        self.catalogs.extend(catalogs)
        self.refresh_files()
        self.file_picker.set_selected(first)
        self.select_catalog()
        if self.settings.auto_review_imports:
            self.queue_quality(catalogs)

    def refresh_files(self):
        self.loading = True
        selected = self.file_picker.get_selected()
        self.file_names.splice(0, self.file_names.get_n_items(),
                               [("● " if c.dirty else "") + c.name for c in self.catalogs])
        if selected < len(self.catalogs):
            self.file_picker.set_selected(selected)
        self.loading = False

    def select_catalog(self, *_):
        if self.loading:
            return
        i = self.file_picker.get_selected()
        if i >= len(self.catalogs):
            return
        self.catalog = self.catalogs[i]
        self.title_widget.set_subtitle(self.catalog.name)
        self.file_picker.set_tooltip_text(self.catalog.origin)
        self.save_button.set_sensitive(True)
        self.filter_units()
        self.update_statistics()

    def setup_row(self, _factory, item):
        outer = Gtk.Box(spacing=6)
        check = Gtk.CheckButton(valign=Gtk.Align.CENTER, tooltip_text="Markera för föröversättning")
        check.connect("toggled", lambda widget: self.toggle_mark(item, widget))
        outer.append(check)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5,
                      margin_top=9, margin_bottom=9, margin_start=6, margin_end=6, hexpand=True)
        for css in ("heading", "dim-label", "caption"):
            line = label("", css)
            line.set_selectable(False)
            line.set_ellipsize(Pango.EllipsizeMode.END)
            box.append(line)
        outer.append(box)
        item.set_child(outer)

    def bind_row(self, _factory, item):
        item.handler = item.get_item().connect("changed", lambda _: self.update_row(item))
        self.update_row(item)

    def unbind_row(self, _factory, item):
        item.get_item().disconnect(item.handler)

    def update_row(self, item):
        unit = item.get_item().unit
        check = item.get_child().get_first_child()
        item.binding = True
        check.set_active((id(self.catalog), unit.key) in self.marked)
        item.binding = False
        box = check.get_next_sibling()
        source = box.get_first_child()
        target = source.get_next_sibling()
        state = target.get_next_sibling()
        source.set_label(f"{item.get_item().number}. " + unit.source.replace("\n", " ↵ "))
        target.set_label((unit.targets[0] or "Skriv en svensk översättning…").replace("\n", " ↵ "))
        state.set_label(unit.status + (" · " + unit.context[:40] if unit.context else ""))

    def toggle_mark(self, item, check):
        if getattr(item, "binding", False) or not item.get_item() or not self.catalog:
            return
        identity = (id(self.catalog), item.get_item().unit.key)
        if check.get_active():
            self.marked.add(identity)
        else:
            self.marked.discard(identity)
        self.update_list_count()
        if FILTERS[self.filter.get_selected()][0] == "marked":
            self.dispatch(self.filter_units)

    def update_list_count(self):
        if self.catalog:
            marked = sum((id(self.catalog), u.key) in self.marked for u in self.catalog.units)
            self.list_count.set_label(f"{self.unit_store.get_n_items()} av {len(self.catalog.units)} · {marked} markerade")

    def mark_visible(self, active):
        if not self.catalog:
            return
        if not active:
            self.marked = {key for key in self.marked if key[0] != id(self.catalog)}
        for row in self.unit_store:
            if active:
                self.marked.add((id(self.catalog), row.unit.key))
            row.emit("changed")
        self.update_list_count()

        if FILTERS[self.filter.get_selected()][0] == "marked":
            self.filter_units()

    def filter_units(self):
        if not self.catalog:
            return
        previous = self.unit
        query = self.search.get_text().casefold()
        kind = FILTERS[self.filter.get_selected()][0]
        rows = [(number, u) for number, u in enumerate(self.catalog.units, 1)
                if matches(u, kind, marked=kind == "marked" and (id(self.catalog), u.key) in self.marked,
                           quality_groups=self.quality_groups(self.catalog, u) if kind.startswith("quality-") else ())
                 and (not query or query in "\n".join([u.source, *u.targets, u.context, u.notes]).casefold())]
        units = [unit for _, unit in rows]
        self.loading = True
        self.unit_store.splice(0, self.unit_store.get_n_items(), [UnitRow(unit, number) for number, unit in rows])
        index = next((i for i, u in enumerate(units) if u is previous or (previous and u.key == previous.key)), 0)
        if units:
            self.selection.set_selected(index)
        self.loading = False
        self.update_list_count()
        self.select_unit()

    def select_unit(self, *_):
        if self.loading:
            return
        selected = self.selection.get_selected_item()
        self.unit = selected.unit if selected else None
        self.loading = True
        self.variant = 0
        self.variants.set_model(Gtk.StringList.new(self.unit.variants if self.unit else ["Översättning"]))
        self.variants.set_selected(0)
        self.loading = False
        clear(self.proposal_box)
        self.show_unit()

    def select_variant(self, *_):
        if not self.loading and self.unit:
            self.variant = min(self.variants.get_selected(), len(self.unit.targets) - 1)
            clear(self.proposal_box)
            self.show_unit()

    def show_unit(self):
        self.loading = True
        unit = self.unit
        self.target_view.set_sensitive(unit is not None)
        self.ai_button.set_sensitive(unit is not None and not unit.source_is_key)
        self.review_button.set_sensitive(unit is not None)
        self.source_view.get_buffer().set_text(unit.source_for(self.variant) if unit else "")
        # Switching units starts a new undo history, so undo cannot mix separate messages.
        self.target_buffer.set_enable_undo(False)
        self.target_buffer.set_text(unit.targets[self.variant] if unit else "")
        self.target_buffer.set_enable_undo(True)
        self.context_label.set_label((unit.context or "Ingen kontext angiven") if unit else "Ingen sträng vald")
        self.notes.set_label("\n".join(filter(None, [unit.notes, unit.references])) if unit else "")
        self.variants.set_visible(bool(unit and len(unit.targets) > 1))
        self.loading = False
        self.update_editor_status()
        self.refresh_suggestions()
        self.schedule_check()

    def target_changed(self, _buffer):
        if self.loading or not self.unit:
            return
        self.unit.edit(self.variant, self.target_buffer.get_text(*self.target_buffer.get_bounds(), True))
        clear(self.proposal_box)
        selected = self.selection.get_selected_item()
        if selected:
            selected.emit("changed")
        self.update_editor_status()
        self.schedule_check()

    def update_editor_status(self):
        if self.unit:
            self.unit_status.set_label(self.unit.status)
            self.length_label.set_label(f"{len(self.unit.targets[self.variant])} tecken")
        if self.catalog:
            # An edited current unit proves dirtiness without rescanning a large file on every keypress.
            dirty = (self.unit is not None and self.unit.changed) or self.catalog.dirty
            self.set_title(("● " if dirty else "") + self.catalog.name + " — Ordverk")

    def copy_source(self):
        if self.unit and not self.unit.source_is_key:
            self.set_target(self.unit.source_for(self.variant))

    def set_target(self, text):
        if self.unit:
            self.target_buffer.begin_user_action()
            self.target_buffer.delete(*self.target_buffer.get_bounds())
            self.target_buffer.insert(self.target_buffer.get_start_iter(), text)
            self.target_buffer.end_user_action()

    def schedule_check(self):
        self.check_generation += 1
        self.check_meter = None
        self.check_bar.set_visible(False)
        generation = self.check_generation
        if hasattr(self, "check_timer") and self.check_timer:
            GLib.source_remove(self.check_timer)
            self.check_timer = None
        if not self.unit:
            return
        self.check_timer = GLib.timeout_add(450, self.run_check, generation)

    def run_check(self, generation):
        self.check_timer = None
        self.update_statistics()
        if not self.unit:
            return False
        unit, variant = copy.deepcopy(self.unit), self.variant
        if self.check_future:
            self.check_future.cancel()
        catalog, quality = self.catalog, self.quality
        def check():
            return [issue for form in range(len(unit.targets)) for issue in quality.check(unit, form)]
        future = self.check_executor.submit(check)
        self.check_future = future
        self.check_meter = ProgressState()
        self.start_progress_timer()

        def done(f):
            if f.cancelled():
                return
            def display():
                if generation != self.check_generation:
                    return
                self.check_meter = None
                self.check_bar.set_visible(False)
                try:
                    issues = f.result()
                    if quality is not self.quality or signature(unit) != signature(self.unit):
                        return
                    self.quality_index(catalog).record(unit, issues)
                    self.show_issues([issue for issue in issues if issue.variant == variant])
                    self.update_quality_view(refilter=True)
                except Exception as exc:
                    clear(self.issue_box)
                    self.issue_box.append(label(f"Kontrollen kunde inte köras: {exc}", "warning", wrap=True))
            self.dispatch(display)
        future.add_done_callback(done)
        return False

    def show_issues(self, issues):
        clear(self.issue_box)
        if not issues:
            self.issue_box.append(label("Inga avvikelser hittades av de aktiva kontrollerna.", "success", wrap=True))
        for issue in issues[:30]:
            line = label(f"{issue.tool} · {issue.message}", "error" if issue.severity == "error" else
                         "warning" if issue.severity == "warning" else "dim-label", wrap=True)
            line.set_tooltip_text(issue.rule)
            self.issue_box.append(line)

    def refresh_suggestions(self):
        if not hasattr(self, "memory_box"):
            return
        clear(self.memory_box)
        clear(self.term_box)
        self.suggestion_generation += 1
        if self.suggestion_future:
            self.suggestion_future.cancel()
        generation = self.suggestion_generation
        self.suggestion_meter = None
        if not self.unit:
            return
        unit = self.unit
        if unit.source_is_key:
            self.memory_box.append(label("Koppla käll-JSON via menyn för att söka på rätt källtext.", "dim-label", wrap=True))
            return
        source, context = unit.source_for(self.variant), unit.context
        self.suggestion_meter = ProgressState()
        self.start_progress_timer()
        future = self.executor.submit(lambda: (self.store.memory(source, context, 8), self.store.terminology(source, 8)))
        self.suggestion_future = future
        def finish(f):
            def display():
                if generation != self.suggestion_generation:
                    return
                self.suggestion_meter = None
                self.suggestion_bar.set_visible(False)
                try:
                    self.show_suggestions(*f.result())
                except Exception as exc:
                    self.memory_box.append(label(f"Språkstödet kunde inte läsas: {exc}", wrap=True))
            self.dispatch(display)
        future.add_done_callback(finish)

    def show_suggestions(self, matches, terms):
        grouped = {}
        for match in matches:
            grouped.setdefault((match.source, match.target), []).append(match)
        for group in list(grouped.values())[:3]:
            match = group[0]
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
            origin = match.origin if len(group) == 1 else f"{len(group)} minneskällor"
            provenance = label(f"{match.score:.0%} likhet · {origin}", "caption", wrap=True)
            provenance.set_tooltip_text("\n".join(m.origin + " · " + m.context for m in group))
            card.append(provenance)
            card.append(label(match.source, "dim-label", wrap=True))
            card.append(label(match.target, wrap=True))
            if match.context:
                card.append(label(match.context[:200], "caption", wrap=True))
            use = button("Använd förslag", lambda text=match.target: self.use_suggestion(text, "memory"))
            use.set_halign(Gtk.Align.START)
            card.append(use)
            self.memory_box.append(card)
        if not matches:
            self.memory_box.append(label("Inga minnesträffar. Resurser hämtas via inställningarna.", "dim-label", wrap=True))
        for term in terms:
            self.term_box.append(label(f"{term.source} → {term.target}", wrap=True))
            consensus = f"{term.score:.0%} konsensus" if term.score is not None else "Konsensus inte angiven"
            self.term_box.append(label(f"{consensus} · {term.origin}", "caption", wrap=True))
        if not terms:
            self.term_box.append(label("Inga matchande termer.", "dim-label"))

    def request_ai(self):
        if not self.unit:
            return
        if not is_configured(self.settings):
            Preferences(self).present()
            self.toast("Välj och konfigurera en översättningstjänst för att få förslag.")
            return
        unit, variant, revision = self.unit, self.variant, self.unit.revision
        snapshot = copy.deepcopy(unit)
        translator = self.translator
        context = catalog_context(self.catalog, unit, self.settings.ai_context_neighbors)

        def done(proposal):
            if self.unit is not unit or unit.revision != revision or self.variant != variant:
                self.toast("Strängen ändrades under API-anropet. Begär ett nytt förslag.")
                return
            clear(self.proposal_box)
            self.proposal_box.append(label(f"AI-förslag · {proposal.model}", "heading", wrap=True))
            self.proposal_box.append(label(proposal.translation, wrap=True))
            self.proposal_box.append(label(proposal.explanation, "dim-label", wrap=True))
            def apply():
                if self.unit is not unit or unit.revision != revision or self.variant != variant:
                    self.toast("Strängen har ändrats. Begär ett nytt förslag.")
                    return
                self.use_suggestion(proposal.translation, "ai")
            use = button("Använd AI-förslag", apply, css="suggested-action")
            errors = [i for i in proposal.issues if i.severity == "error"]
            use.set_sensitive(not errors)
            self.proposal_box.append(use)
            for issue in errors:
                self.proposal_box.append(label(issue.message, "error", wrap=True))
            self.status.set_label("AI-förslaget är klart för granskning")
        self.job("Ber om ett AI-förslag…", lambda cancel: translator.suggest(snapshot, variant, cancel, context), done)

    def preview_ai_context(self, settings=None, parent=None):
        if not self.unit or not self.catalog:
            self.toast("Välj en sträng för att se översättningskontexten.")
            return
        settings = settings or self.settings
        unit, variant = copy.deepcopy(self.unit), self.variant
        context = catalog_context(self.catalog, self.unit, settings.ai_context_neighbors)
        translator = Translator(settings, self.store, self.quality)
        self.job("Samlar översättningskontext…", lambda _: translator.preview(unit, variant, context),
                 lambda text: self.show_report("Kontext till översättningen", [text], parent=parent))

    def mark_reviewed(self):
        if not self.unit:
            return
        if not all(self.unit.targets):
            self.toast("Översätt alla plural- och längdvarianter först.")
            return
        unit, revision, catalog = self.unit, self.unit.revision, self.catalog
        snapshot = copy.deepcopy(unit)

        def check(_cancel):
            return [issue for variant in range(len(snapshot.targets)) for issue in self.quality.check(snapshot, variant)]

        def done(issues):
            if unit.revision != revision:
                self.toast("Strängen ändrades under granskningen. Granska den igen.")
                return
            errors = [i for i in issues if i.severity == "error"]
            if errors:
                self.show_report("Åtgärda dessa fel först", [i.message for i in errors])
                return
            unit.reviewed = True
            unit.revision += 1
            self.refresh_files()
            if self.catalog is catalog:
                self.filter_units()
            self.status.set_label("Strängen är granskad")
            if not unit.source_is_key:
                values = [(unit.source_for(v), target, unit.context) for v, target in enumerate(unit.targets)]
                self.job("Sparar i ditt eget översättningsminne…", lambda _: [self.store.remember(*value) for value in values],
                         lambda _: self.status.set_label("Granskad · sparad som förslag i ditt eget översättningsminne"))
        self.job("Kontrollerar alla varianter…", check, done)

    def start_workflow(self, catalogs, purpose, automatic, use_ai):
        if not automatic:
            self.status.set_label("Manuell granskning · välj en sträng" if purpose == "review" else "Manuell översättning · välj en sträng")
        elif purpose == "review":
            self.review_catalogs(catalogs)
        else:
            if use_ai and not is_configured(self.settings):
                self.error("Konfigurera en översättningstjänst innan automatisk AI-översättning startas.")
                Preferences(self).present()
                return

            def done(result):
                changes, messages = result
                applied, skipped = self.apply_translations(changes)
                self.refresh_files()
                self.filter_units()
                self.update_statistics()
                self.status.set_label(f"{applied} förslag tillämpade · {skipped} ändrade strängar hoppades över · spara när du är klar")
                if messages:
                    self.show_report("Automatiskt arbete", messages)
            self.job("Översätter tomma strängar…", lambda cancel: batch_translate(
                catalogs, self.store, self.quality, self.translator if use_ai else None,
                limit=self.settings.automatic_limit, cancel=cancel, progress=self.progress_message), done)

    def pretranslate(self):
        if self.catalog:
            PretranslateDialog(self).present()
        else:
            self.toast("Importera en fil först.")

    def apply_translations(self, changes):
        def count(change):
            self.session_statistics["ai" if change.origin.startswith("AI ·") else "memory"] += 1
        return apply_changes(changes, on_applied=count)

    def run_pretranslation(self, catalog, selected, method, overwrite):
        return self.job("Tar fram föröversättningar…", lambda cancel: batch_translate(
            [catalog], self.store, self.quality, self.translator if method != "resources" else None,
            selected=selected, method=method, overwrite=overwrite, limit=None, cancel=cancel,
            progress=self.progress_message), self.preview_changes)

    def preview_changes(self, result):
        changes, messages = result
        dialog = Adw.Window(transient_for=self, title="Granska föröversättningar", default_width=800, default_height=620)
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        root.append(Adw.HeaderBar())
        root.append(label(f"{len(changes)} förslag · ändringar sparas när du väljer Spara", "heading", wrap=True))
        text = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.WORD_CHAR,
                            left_margin=20, right_margin=20)
        catalogs = {id(c.catalog): c.catalog for c in changes}
        units = {(identity, u.key): u for identity, catalog in catalogs.items() for u in catalog.units}
        rows = [f"{units[(id(c.catalog), c.key)].source_for(c.variant)}\nFöre: {c.before or '(tomt)'}\nFörslag: {c.after}\n{c.origin}"
                + ("\n" + "\n".join(i.message for i in c.issues) if c.issues else "") for c in changes]
        text.get_buffer().set_text("\n\n".join(rows + messages) or "Inga nya förslag. Kontrollera källtexter och tillgängliga språkresurser.")
        root.append(scroll(text, vexpand=True))
        def apply():
            applied, skipped = self.apply_translations(changes)
            self.refresh_files()
            self.filter_units()
            self.update_statistics()
            self.toast(f"{applied} förslag tillämpades. {skipped} strängar hade ändrats och hoppades över.")
            dialog.close()
        controls = Gtk.Box(spacing=12, halign=Gtk.Align.END, margin_bottom=18, margin_end=18)
        controls.append(button("Stäng", dialog.close))
        use = button("Tillämpa förslagen", apply, css="suggested-action")
        use.set_sensitive(bool(changes))
        controls.append(use)
        root.append(controls)
        dialog.set_content(root)
        dialog.present()

    def review_catalogs(self, catalogs):
        quality = self.quality
        def run(cancel):
            results = []
            for original in catalogs:
                if cancel.is_set():
                    break
                catalog = copy.deepcopy(original)
                self.progress_message("Granskar " + catalog.name)
                results.append((original, catalog, quality.catalog(catalog, cancel=cancel, progress=self.progress_message)))
            return results

        def done(results):
            if quality is not self.quality:
                self.toast("Inställningarna ändrades under granskningen. Granska filen igen.")
                return
            self.diagnostics = []
            for original, snapshot, issues in results:
                self.quality_index(original).apply(original, snapshot, issues)
                self.diagnostics.extend({"file": original.name, **asdict(issue)} for issue in issues)
            self.report_ready = True
            self.update_quality_view(refilter=True)
            self.show_report("Granskning av kataloger", [f"{i['file']}: {i['message']}" for i in self.diagnostics]
                             or ["De aktiva kvalitetskontrollerna hittade inga avvikelser."])
            self.status.set_label(f"Granskningen är klar · {len(self.diagnostics)} avvikelser")
        self.job("Granskar kataloger…", run, done)

    def show_report(self, title, messages, parent=None):
        window = Adw.Window(transient_for=parent or self, modal=False, title=title, default_width=720, default_height=480)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.append(Adw.HeaderBar())
        text = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.WORD_CHAR,
                            left_margin=20, right_margin=20, top_margin=16, bottom_margin=20)
        text.get_buffer().set_text("\n\n".join(messages[:1000]) + (f"\n\n… och {len(messages)-1000} till." if len(messages) > 1000 else ""))
        box.append(scroll(text, vexpand=True))
        window.set_content(box)
        window.present()

    def save(self, save_as=False, *, catalog=None, on_saved=None):
        catalog = catalog or self.catalog
        if not catalog or self.busy:
            if self.busy:
                self.toast("Avsluta pågående arbete innan du sparar.")
            return

        def write(path):
            def finish(overwrite=False):
                if self.busy:
                    self.toast("Låt det pågående arbetet bli klart innan du sparar.")
                    return
                self.stack.set_sensitive(False)
                def operation(cancel):
                    if cancel.is_set():
                        return None
                    snapshot = copy.deepcopy(catalog)
                    stamp_translator(snapshot, self.settings)
                    snapshot.save(path, overwrite=overwrite)
                    return snapshot
                def saved(result):
                    if result is None:
                        self.status.set_label("Sparningen avbröts.")
                        return
                    catalog.__dict__.update(result.__dict__)
                    self.refresh_files()
                    if self.catalog is catalog:
                        self.filter_units()
                    self.toast("Filen har sparats. Tidigare innehåll finns som säkerhetskopia.")
                    self.status.set_label("Sparad · " + str(path))
                    self.update_statistics()
                    if on_saved:
                        on_saved()
                self.job("Sparar filen…", operation, saved)
            if Path(path).exists() and Path(path).absolute() != catalog.path:
                dialog = Adw.MessageDialog(transient_for=self, heading="Ersätta den befintliga filen?", body=str(path))
                dialog.add_response("cancel", "Avbryt")
                dialog.add_response("replace", "Ersätt")
                dialog.set_response_appearance("replace", Adw.ResponseAppearance.DESTRUCTIVE)
                dialog.connect("response", lambda _d, response: finish(True) if response == "replace" else None)
                dialog.present()
            else:
                finish()
        if save_as or not catalog.path or catalog.ext == ".pot":
            name = Path(catalog.name).name
            if catalog.ext == ".pot":
                name = Path(name).stem + ".sv.po"
            self.file_dialog("Spara översättning", write, save_name=name)
        else:
            write(catalog.path)

    def choose_reference(self):
        catalog = self.catalog
        if not catalog:
            return
        def attach(path):
            snapshot = copy.deepcopy(catalog)
            def read(_):
                return snapshot.attach_reference(path)
            def done(count):
                for source, target in zip(snapshot.units, catalog.units):
                    if source.source != target.source or source.source_is_key != target.source_is_key:
                        target.source, target.source_is_key = source.source, source.source_is_key
                        target.reviewed = False
                        target.revision += 1
                catalog.reference = snapshot.reference
                self.filter_units()
                self.toast(f"Källtext kopplad för {count} strängar. Spara filen för att behålla kopplingen.")
            self.job("Läser källtexter…", read, done)
        self.file_dialog("Koppla engelsk käll-JSON", attach, patterns=["*.json"])

    def choose_resource(self, kind):
        def load(path):
            operation = self.store.import_po if kind == "memory" else self.store.import_terms
            self.job("Indexerar språkresurs…", lambda cancel: operation(path, cancel=cancel),
                     lambda count: (self.toast(f"{count} poster importerades."), self.refresh_suggestions()))
        self.file_dialog("Importera översättningsminne" if kind == "memory" else "Importera terminologi", load,
                         patterns=["*.po"] if kind == "memory" else ["*.tbx", "*.csv"])

    def export_report(self):
        if not self.report_ready:
            self.toast("Kör en filgranskning först. Rapporten exporterar den senaste körningen.")
            return
        self.file_dialog("Exportera senaste granskningsrapport", lambda path: self.job("Exporterar rapport…", lambda _: atomic_write(
            Path(path), json.dumps(self.diagnostics, ensure_ascii=False, indent=2).encode(), 0o644), lambda _: self.toast("Rapporten har exporterats.")),
            save_name="ordverk-granskning.json")

    def export_files(self):
        if not self.catalog:
            self.toast("Importera en fil först.")
            return
        dialog = ExportDialog(self)
        dialog.present()
        return dialog

    def edit_po_header(self):
        if not self.catalog or self.catalog.ext not in {".po", ".pot"}:
            self.toast("Välj en PO- eller POT-fil först.")
            return
        dialog = HeaderDialog(self)
        dialog.present()
        return dialog

    def export_memory(self):
        self.file_dialog("Exportera eget granskat minne", lambda path: self.job("Exporterar minne…", lambda _: self.store.export_memory(path),
                                                                               lambda _: self.toast("Minnet har exporterats.")), save_name="ordverk-minne.po")

    def use_suggestion(self, text, kind):
        if self.unit and self.unit.targets[self.variant] != text:
            self.session_statistics[kind] += 1
            self.set_target(text)

    def update_statistics(self):
        total = statistics(self.catalogs)
        self.update_quality_view()
        for key, widget in self.statistics_labels.items():
            widget.set_label(f"{getattr(total, key):,}".replace(",", " "))
        self.completion.set_fraction(total.fraction)
        self.completion.set_text(f"{total.fraction:.0%} översatt")
        self.completion.set_tooltip_text("Alla importerade filer. En sträng räknas som översatt när alla dess plural- och längdvarianter är ifyllda.")

    def refresh_statistics_views(self, *, progress_only=False):
        for refresh in list(self.statistics_views):
            refresh(progress_only)

    def show_statistics(self, *, catalogs=None, title="Statistik"):
        catalogs = list(self.catalogs if catalogs is None else catalogs)
        window = Adw.Window(transient_for=self, title=title, default_width=850, default_height=600, destroy_with_parent=True)
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        root.append(Adw.HeaderBar())
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18,
                      margin_start=24, margin_end=24, margin_top=18, margin_bottom=24)
        heading = label(title, "title-1")
        heading.set_selectable(False)
        box.append(heading)
        totals = label(wrap=True)
        box.append(totals)
        progress = Gtk.ProgressBar(show_text=True, visible=False)
        box.append(progress)
        stop = button("Avbryt kvalitetsgranskning", self.cancel_quality)
        stop.set_visible(False)
        box.append(stop)
        file_labels = []
        for catalog in catalogs:
            heading = label(catalog.name, "heading")
            box.append(heading)
            counts_label, quality_label = label(wrap=True), label(wrap=True)
            box.append(counts_label)
            box.append(quality_label)
            file_labels.append((catalog, counts_label, quality_label))
        box.append(label("Kvalitetssiffrorna räknar strängar, inte antal anmärkningar. En sträng kan ingå i flera grupper. Stavfel och avvikande skiftläge behöver bedömas i sitt sammanhang. Strängar som inte har kontrollerats räknas inte som felfria.", "dim-label", wrap=True))
        box.append(label("Granskad betyder manuellt godkänd. Statistiken omfattar osparade ändringar.", "dim-label", wrap=True))
        close_button = button("Stäng", window.close)
        box.append(close_button)
        root.append(scroll(box, vexpand=True))
        window.set_content(root)

        def refresh(progress_only=False):
            meter = self.quality_meter if self.quality_running in catalogs else None
            visible = meter is not None and meter.visible()
            progress.set_visible(visible)
            stop.set_visible(visible)
            if visible:
                if meter.fraction is None:
                    progress.set_text("Granskar filen…")
                    progress.pulse()
                else:
                    progress.set_fraction(meter.fraction)
                    progress.set_text(f"{self.quality_running.name} · {meter.current} av {meter.total} · {meter.fraction:.0%}")
            if progress_only:
                return
            total = statistics(catalogs)
            file_word = "fil" if total.files == 1 else "filer"
            engines = [name for name, enabled in (("Hunspell", self.settings.use_hunspell), ("Aspell", self.settings.use_aspell)) if enabled]
            spelling = " och ".join(engines) if engines else "inbyggda regler; Hunspell och Aspell är avstängda"
            totals.set_label(f"{total.files} {file_word} · {total.total} strängar · {total.source_words} ord i källtexterna\n"
                             f"{total.translated} översatta · {total.reviewed} granskade · {total.needs_review} att granska · {total.remaining} återstår\n"
                             f"Plural- och längdvarianter: {total.translated_variants} av {total.variants} ifyllda.\n"
                             f"Tillämpade förslag denna session: {self.session_statistics['memory']} från språkresurser, {self.session_statistics['ai']} från AI.\n"
                             f"Stavningskontroll: {spelling}.")
            for catalog, counts_label, quality_label in file_labels:
                counts = statistics([catalog])
                index = self.quality_index(catalog)
                quality_counts = index.counts(catalog)
                counts_label.set_label(f"{counts.total} strängar · {counts.translated} översatta · {counts.reviewed} granskade · {counts.remaining} återstår")
                quality_label.set_label(index.summary(catalog) + "\n" + " · ".join(
                    f"{quality_counts[key]} {caption}" for key, caption in (
                        ("placeholders", "med fel i platshållare"), ("markup", "med fel i taggar"),
                        ("punctuation", "med avvikande skiljetecken"), ("whitespace", "med blankstegs- eller radbrytningsfel"),
                        ("numbers", "med avvikande tal eller datum"), ("terminology", "med terminologianmärkningar"))))
                if index.file_issues:
                    quality_label.set_label(quality_label.get_label() + f"\n{len(index.file_issues)} anmärkningar för hela filen eller granskningsverktygen:\n" +
                                            "\n".join(issue.message for issue in index.file_issues[:5]) +
                                            ("\nFler detaljer finns under Granska fil." if len(index.file_issues) > 5 else ""))
                quality_label.set_tooltip_text("\n".join(issue.message for issue in index.file_issues))
        def close(*_):
            if refresh in self.statistics_views:
                self.statistics_views.remove(refresh)
            return False
        window.connect("close-request", close)
        self.statistics_views.append(refresh)
        refresh()
        window.present()
        close_button.grab_focus()
        return window

    def move(self, delta):
        count = self.unit_store.get_n_items()
        if count:
            self.selection.set_selected(max(0, min(count - 1, self.selection.get_selected() + delta)))

    def about(self):
        dialog = Adw.AboutWindow(transient_for=self, modal=True, application_name="Ordverk", version=__version__,
                                  application_icon="io.github.yeager.Ordverk",
                                  developer_name="Daniel Nylander",
                                  developers=["Daniel Nylander https://github.com/yeager"],
                                  copyright="© 2026 Daniel Nylander",
                                  website="https://github.com/yeager/ordverk",
                                  issue_url="https://github.com/yeager/ordverk/issues",
                                  comments="En svensk översättningsverkstad.\nGTK4 · libadwaita · Python",
                                  license_type=Gtk.License.GPL_3_0)
        dialog.add_credit_section("Språkverktyg och språkresurser", [
            f"{name} https://github.com/yeager/{name}"
            for name in ("swedish-tm", "swedish-foss-terminology", "l10n-lint", "svlang", "hunspell-sv", "aspell-sv")
        ])
        dialog.add_acknowledgement_section("Bibliotek och plattform", [
            "GTK https://www.gtk.org/",
            "libadwaita https://gnome.pages.gitlab.gnome.org/libadwaita/",
            "PyGObject https://pygobject.gnome.org/",
            "polib https://pypi.org/project/polib/",
            "lxml https://lxml.de/",
            "keyring https://pypi.org/project/keyring/",
            "GNU Gettext https://www.gnu.org/software/gettext/",
        ])
        dialog.present()
        return dialog

    def on_close(self, *_):
        if self.close_dialog:
            self.close_dialog.present()
            return True
        dirty = [catalog for catalog in self.catalogs if catalog.dirty]
        if dirty or self.busy:
            names = "\n".join(catalog.name for catalog in dirty[:8])
            if len(dirty) > 8:
                names += f"\n… och {len(dirty) - 8} till."
            body = f"{len(dirty)} filer har osparade ändringar:\n{names}" if dirty else ""
            if self.busy:
                body += "\n\nLåt det pågående arbetet bli klart eller avbryt det med Avbryt innan du avslutar."
            dialog = Adw.MessageDialog(transient_for=self, modal=True,
                                       heading="Du har osparade ändringar" if dirty else "Arbete pågår", body=body.strip())
            self.close_dialog = dialog
            dialog.add_response("cancel", "Fortsätt arbeta")
            dialog.set_default_response("cancel")
            dialog.set_close_response("cancel")
            if not self.busy:
                dialog.add_response("discard", "Stäng utan att spara")
                dialog.add_response("save", "Spara alla och avsluta")
                dialog.set_response_appearance("discard", Adw.ResponseAppearance.DESTRUCTIVE)
                dialog.set_response_appearance("save", Adw.ResponseAppearance.SUGGESTED)
            def respond(_dialog, response):
                self.close_dialog = None
                if response == "save":
                    self.save_before_close()
                elif response == "discard" and not self.busy:
                    self.shutdown()
            dialog.connect("response", respond)
            dialog.present()
            return True
        self.shutdown()
        return True

    def save_before_close(self):
        if self.busy or self.closed:
            return
        dirty = next((catalog for catalog in self.catalogs if catalog.dirty), None)
        if dirty is None:
            self.shutdown()
            return
        self.file_picker.set_selected(self.catalogs.index(dirty))
        self.save(catalog=dirty, on_saved=self.save_before_close)

    def shutdown(self):
        if self.closed:
            return
        self.closed = True
        self.job_cancel.set()
        self.resource_cancel.set()
        self.check_generation += 1
        if self.progress_timer:
            GLib.source_remove(self.progress_timer)
            self.progress_timer = None
        if getattr(self, "check_timer", None):
            GLib.source_remove(self.check_timer)
            self.check_timer = None
        self.executor.shutdown(wait=False, cancel_futures=True)
        self.quality_cancel.set()
        self.quality_queue.clear()
        self.statistics_views.clear()
        self.review_executor.shutdown(wait=False, cancel_futures=True)
        self.check_executor.shutdown(wait=False, cancel_futures=True)
        self.destroy()


class Application(Adw.Application):
    def __init__(self):
        super().__init__(application_id="io.github.yeager.Ordverk", flags=Gio.ApplicationFlags.HANDLES_OPEN)
        GLib.set_application_name("Ordverk")

    def do_activate(self):
        window = self.get_active_window()
        if not window:
            window = Window(self)
        window.present()

    def do_open(self, files, *_):
        self.activate()
        self.get_active_window().import_paths([file.get_path() or file.get_uri() for file in files])


def run():
    return Application().run(sys.argv)

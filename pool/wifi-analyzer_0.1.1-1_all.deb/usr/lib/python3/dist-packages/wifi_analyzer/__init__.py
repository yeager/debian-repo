"""WiFi Analyzer — WiFi Network Analysis Tool."""
__version__ = "0.1.1"
